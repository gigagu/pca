package tenant

// this is for read platform config and do rolebinding

// when create namespace, create rolebinding and role
