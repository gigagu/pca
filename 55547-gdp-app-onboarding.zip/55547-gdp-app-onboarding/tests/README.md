# Test Documentation

This directory contains test cases for the GDP Tenant Onboarding Pipeline.

## Running Tests

### Install Test Dependencies

```bash
pip install -r ../requirements.txt
```

### Run All Tests

```bash
# From project root directory
pytest tests/

# Or from tests directory
cd tests
pytest
```

### Run Specific Test Files

```bash
# Test main pipeline
pytest tests/test_main.py

# Test individual steps
pytest tests/test_steps.py
```

### Run Specific Test Classes or Methods

```bash
# Run specific test class
pytest tests/test_main.py::TestParseManifest

# Run specific test method
pytest tests/test_main.py::TestParseManifest::test_parse_valid_manifest
```

### View Detailed Output

```bash
pytest -v  # Verbose output
pytest -s  # Show print output
pytest -vv # More verbose output
```

## Test Structure

- `test_main.py`: Tests for main pipeline, including manifest parsing and tenant processing
- `test_steps.py`: Tests for individual step modules

## Test Coverage

### test_main.py
- `parse_manifest`: Tests manifest file parsing
- `process_tenant`: Tests tenant processing flow (dry-run and actual execution)
- `load_env_config`: Tests environment configuration loading

### test_steps.py
- `TestK8sResources`: Tests K8s resource creation
- `TestMinioBucket`: Tests MinIO bucket creation (including dev environment skip logic)
- `TestRangerPolicy`: Tests Ranger policy creation
- `TestPodTemplate`: Tests Pod template generation and upload
- `TestTrinoResourceGroup`: Tests Trino resource group configuration
- `TestYuniKornQueue`: Tests YuniKorn queue updates

## Notes

1. Most tests use mock objects and do not require actual K8s clusters or external services
2. Some tests may require environment variables (e.g., TRINO_USER, TRINO_PASSWORD), but these are mocked in the tests
3. Test files automatically add the `src` directory to Python path to ensure correct module imports
