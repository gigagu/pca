import unittest
import os

class MyTestEnv(unittest.TestCase):
    def test_env(self):
        endpoint = os.getenv("MINIO_ENDPOINT")
        access_key = os.getenv("MINIO_ACCESS_KEY")
        secret_key = os.getenv("MINO_SECRET_KEY")  # Note: typo in env var name
        self.assertEqual(endpoint, "https://minio-os1-stg.50821.app.standardchartered.com:4161")  # add assertion here
        self.assertEqual(access_key, "55547-gdp-sit")  # add assertion here
        self.assertEqual(secret_key, "xwhgEA82FSp72fc2Rw")  # add assertion here


if __name__ == '__main__':
    unittest.main()
