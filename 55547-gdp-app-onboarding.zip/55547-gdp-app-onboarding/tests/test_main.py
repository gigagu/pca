"""
Test cases for main.py - manifest parsing and pipeline orchestration.
"""
import pytest
import yaml
from pathlib import Path
from unittest.mock import patch, MagicMock

import sys
import os

# Add src to path
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src_dir = os.path.join(parent_dir, "src")
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from main import parse_manifest, process_tenant
from utils.utils import load_env_config


class TestParseManifest:
    """Test cases for parse_manifest function."""
    
    def test_parse_valid_manifest(self, tmp_path):
        """Test parsing a valid manifest file."""
        manifest_content = {
            "meta-data": {
                "manifest-schema": "v1",
                "manifest-version": "1.0"
            },
            "platform-config": [
                {
                    "tenant-itam": 55547,
                    "tenant-name": "test",
                    "resource-quotas": {"cpu": "4", "memory": "8Gi"},
                    "object-store-buckets": []
                }
            ]
        }
        
        manifest_file = tmp_path / "manifest.yml"
        with manifest_file.open("w", encoding="utf-8") as f:
            yaml.dump(manifest_content, f)
        
        result = parse_manifest(manifest_file)
        assert result == manifest_content
        assert "platform-config" in result
    
    def test_parse_empty_manifest(self, tmp_path):
        """Test parsing an empty manifest file."""
        manifest_file = tmp_path / "empty.yml"
        manifest_file.write_text("")
        
        with pytest.raises(ValueError, match="empty or invalid"):
            parse_manifest(manifest_file)
    
    def test_parse_nonexistent_file(self, tmp_path):
        """Test parsing a non-existent file."""
        manifest_file = tmp_path / "nonexistent.yml"
        
        with pytest.raises(FileNotFoundError):
            parse_manifest(manifest_file)


class TestProcessTenant:
    """Test cases for process_tenant function."""
    
    @pytest.fixture
    def sample_platform_config(self):
        """Sample platform configuration."""
        return {
            "tenant-itam": 55547,
            "tenant-name": "test",
            "resource-quotas": {"cpu": "4", "memory": "8Gi"},
            "tenant-noninteractive-owner": ["group1"],
            "tenant-noninteractive-viewer": ["group2"],
            "tenant-interactive-owner": ["user1"],
            "object-store-buckets": [
                {"name": "test-bucket", "bucket-size": "10Gi"}
            ],
            "ranger-policies": {
                "object-store-buckets": [
                    {"name": "test-bucket", "admin-group": ["admin1"]}
                ],
                "airflow-object-store": {
                    "admin-group": ["admin1"]
                }
            },
            "admin-ad-account": "test-admin"
        }
    
    @pytest.fixture
    def sample_env_config(self):
        """Sample environment configuration."""
        return {
            "platform-common-bucket": "sc-gdp-gbl-common-sit-55547",
            "airflow-prefix": "gdp-platform/airflow/dags",
            "env-configs": {
                "S3_AUTHORIZER_SERVER_BASE_URL": "https://test.example.com",
                "S3_ENDPOINT_URL": "https://minio.test.com",
                "HIVE_ENDPOINT_URL": "thrift://hive.test.com:9083",
                "RANGER_BASE_URL": "https://ranger.test.com"
            }
        }
    
    @patch('main.create_k8s_resources')
    @patch('main.create_minio_buckets')
    @patch('main.configure_trino_resource_group')
    @patch('main.apply_ranger_policies')
    @patch('main.generate_and_upload_pod_template')
    def test_process_tenant_dry_run(
        self,
        mock_pod_template,
        mock_ranger,
        mock_trino,
        mock_minio,
        mock_k8s,
        sample_platform_config,
        sample_env_config,
        tmp_path
    ):
        """Test processing tenant in dry-run mode."""
        result = process_tenant(
            sample_platform_config,
            dry_run=True,
            output_dir=tmp_path,
            env="sit",
            env_config=sample_env_config
        )
        
        assert result["tenantName"] == "t-55547-test"
        assert result["namespace"] == "t-55547-test"
        
        # Verify no actual calls were made in dry-run
        mock_k8s.assert_not_called()
        mock_minio.assert_not_called()
        mock_trino.assert_not_called()
        mock_ranger.assert_not_called()
        mock_pod_template.assert_not_called()
    
    @patch('main.create_k8s_resources')
    @patch('main.create_minio_buckets')
    @patch('main.configure_trino_resource_group')
    @patch('main.apply_ranger_policies')
    @patch('main.generate_and_upload_pod_template')
    def test_process_tenant_with_calls(
        self,
        mock_pod_template,
        mock_ranger,
        mock_trino,
        mock_minio,
        mock_k8s,
        sample_platform_config,
        sample_env_config,
        tmp_path
    ):
        """Test processing tenant with actual step calls."""
        result = process_tenant(
            sample_platform_config,
            dry_run=False,
            output_dir=tmp_path,
            env="sit",
            env_config=sample_env_config
        )
        
        assert result["tenantName"] == "t-55547-test"
        
        # Verify all steps were called
        mock_k8s.assert_called_once()
        mock_minio.assert_called_once()
        mock_trino.assert_called_once()
        mock_ranger.assert_called_once()
        mock_pod_template.assert_called_once()
    
    def test_process_tenant_missing_fields(self, sample_env_config):
        """Test processing tenant with missing required fields."""
        invalid_config = {
            "tenant-name": "test"
            # Missing tenant-itam
        }
        
        with pytest.raises(ValueError, match="Missing required fields"):
            process_tenant(
                invalid_config,
                dry_run=True,
                env="sit",
                env_config=sample_env_config
            )


class TestLoadEnvConfig:
    """Test cases for load_env_config function."""
    
    def test_load_dev_config(self):
        """Test loading dev environment configuration."""
        config = load_env_config("sit")
        assert "platform-common-bucket" in config
        assert "airflow-prefix" in config
        assert "env-configs" in config
        assert config["platform-common-bucket"] == "sc-gdp-gbl-common-sit-55547"
    
    def test_load_prod_config(self):
        """Test loading prod environment configuration."""
        config = load_env_config("prod")
        assert "platform-common-bucket" in config
        assert "airflow-prefix" in config
        assert "env-configs" in config
        assert config["platform-common-bucket"] == "sc-gdp-gbl-common-prod-55547"
    
    def test_load_invalid_env(self):
        """Test loading invalid environment configuration."""
        with pytest.raises(ValueError, match="not found"):
            load_env_config("invalid")


