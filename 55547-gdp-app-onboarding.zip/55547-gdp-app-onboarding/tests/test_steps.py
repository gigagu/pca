"""
Test cases for individual step modules.
"""
import pytest
from unittest.mock import patch, MagicMock, Mock
from typing import Dict, Any, List

import sys
import os

# Add src to path
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src_dir = os.path.join(parent_dir, "src")
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

from steps.k8s_resources import create_k8s_resources
from steps.minio_bucket import create_minio_buckets
from steps.ranger_policy import apply_ranger_policies, create_s3_fullaccess_policy
from steps.pod_template import generate_and_upload_pod_template, build_pod_template
from steps.trino_resource_group import configure_trino_resource_group
from steps.yunikorn_queue import update_yunikorn_queue


class TestK8sResources:
    """Test cases for k8s_resources step."""
    
    @patch('steps.k8s_resources.client.CoreV1Api')
    @patch('steps.k8s_resources.client.RbacAuthorizationV1Api')
    @patch('steps.k8s_resources.load_k8s_config')
    def test_create_k8s_resources(
        self,
        mock_load_config,
        mock_rbac_api,
        mock_core_api
    ):
        """Test creating K8s resources."""
        mock_v1 = MagicMock()
        mock_rbac = MagicMock()
        mock_core_api.return_value = mock_v1
        mock_rbac_api.return_value = mock_rbac
        
        # Mock successful creation
        mock_v1.create_namespace.return_value = None
        mock_v1.create_namespaced_resource_quota.return_value = None
        mock_rbac.create_namespaced_role.return_value = None
        mock_rbac.create_namespaced_role_binding.return_value = None
        
        create_k8s_resources(
            tenant_name="t-55547-test",
            namespace="t-55547-test",
            resource_quotas={"cpu": "4", "memory": "8Gi"},
            noninteractive_owners=["group1"],
            noninteractive_viewers=["group2"]
        )
        
        # Verify calls were made
        mock_v1.create_namespace.assert_called()
        mock_v1.create_namespaced_resource_quota.assert_called()


class TestMinioBucket:
    """Test cases for minio_bucket step."""
    
    @patch('steps.minio_bucket.Minio')
    @patch('steps.minio_bucket.get_minio_credentials')
    def test_create_minio_buckets_dev_skip(
        self,
        mock_get_creds,
        mock_minio_class
    ):
        """Test that MinIO bucket creation is skipped in dev environment."""
        create_minio_buckets([{"name": "test-bucket"}], env="sit")
        
        # Verify MinIO client was not created
        mock_minio_class.assert_not_called()
    
    @patch('steps.minio_bucket.Minio')
    @patch('steps.minio_bucket.get_minio_credentials')
    def test_create_minio_buckets_prod(
        self,
        mock_get_creds,
        mock_minio_class
    ):
        """Test creating MinIO buckets in prod environment."""
        mock_get_creds.return_value = ("endpoint", "access_key", "secret_key")
        mock_client = MagicMock()
        mock_client.bucket_exists.return_value = False
        mock_minio_class.return_value = mock_client
        
        buckets = [{"name": "test-bucket", "bucket-size": "10Gi"}]
        create_minio_buckets(buckets, env="prod")
        
        # Verify MinIO client was created and used
        mock_minio_class.assert_called_once()
        mock_client.make_bucket.assert_called_once()


class TestRangerPolicy:
    """Test cases for ranger_policy step."""
    
    @patch('steps.ranger_policy.post_policy')
    def test_apply_ranger_policies(
        self,
        mock_post_policy
    ):
        """Test applying Ranger policies."""
        ranger_policies = {
            "object-store-buckets": [
                {
                    "name": "test-bucket",
                    "admin-group": ["admin1"],
                    "viewer-group": ["viewer1"]
                }
            ],
            "airflow-object-store": {
                "admin-group": ["admin1"]
            },
            "common-object-store": {
                "common-group": ["common-group1"]
            }
        }
        
        env_config = {
            "platform-common-bucket": "sc-gdp-gbl-common-sit-55547",
            "airflow-prefix": "gdp-platform/airflow/dags",
            "env-configs": {
                "RANGER_BASE_URL": "https://ranger-stg.55547.app.standardchartered.com"
            },
            "ranger-policy-paths": {
                "common-readonly": [
                    "/{platform-common-bucket}/gdp-framework/sit/ingestion_config",
                    "/{platform-common-bucket}/ado"
                ],
                "common-readwrite": [
                    "/{platform-common-bucket}/gdp-platform/logs/sparkhs"
                ]
            }
        }
        
        apply_ranger_policies(
            tenant_name="t-55547-test",
            ranger_policies=ranger_policies,
            platform_bucket="sc-gdp-gbl-common-sit-55547",
            airflow_prefix="gdp-platform/airflow/dags",
            env_config=env_config
        )
        
        # Verify three policies were created (readonly, readwrite, and admin)
        assert mock_post_policy.call_count == 3
        
        # Check readonly policy
        readonly_call = mock_post_policy.call_args_list[0][0][0]
        assert readonly_call["name"] == "t-tenant-common-readonly"
        assert "common-group1" in readonly_call["policyItems"][0]["groups"]
        assert len(readonly_call["policyItems"][0]["accesses"]) == 1  # only read access
        assert readonly_call["policyItems"][0]["accesses"][0]["type"] == "read"
        # Check paths are from config
        paths = readonly_call["resources"]["path"]["values"]
        assert "/sc-gdp-gbl-common-sit-55547/gdp-framework/sit/ingestion_config" in paths
        assert "/sc-gdp-gbl-common-sit-55547/ado" in paths
        
        # Check readwrite policy
        readwrite_call = mock_post_policy.call_args_list[1][0][0]
        assert readwrite_call["name"] == "t-tenant-common-readwrite"
        assert "common-group1" in readwrite_call["policyItems"][0]["groups"]
        assert len(readwrite_call["policyItems"][0]["accesses"]) == 3  # read, write, execute
        # Check paths are from config
        paths = readwrite_call["resources"]["path"]["values"]
        assert "/sc-gdp-gbl-common-sit-55547/gdp-platform/logs/sparkhs" in paths
        
        # Check admin policy
        admin_call = mock_post_policy.call_args_list[2][0][0]
        assert admin_call["name"] == "app-t-55547-test-fullaccess-S3"
        assert "admin1" in admin_call["policyItems"][0]["groups"]
        assert len(admin_call["policyItems"][0]["accesses"]) == 3  # read, write, execute
        # Check paths include bucket and airflow path
        paths = admin_call["resources"]["path"]["values"]
        assert "/test-bucket" in paths
        assert "/sc-gdp-gbl-common-sit-55547/gdp-platform/airflow/dags/t-55547-test" in paths
    
    @patch('steps.ranger_policy.post_policy')
    def test_create_s3_policy(
        self,
        mock_post_policy
    ):
        """Test creating S3 policy."""
        from steps.ranger_policy import create_s3_policy
        
        create_s3_policy(
            policy_name="test-policy",
            paths=["/bucket1", "/bucket2"],
            groups=["group1"],
            access_types=["read", "write", "execute"]
        )
        
        mock_post_policy.assert_called_once()
        policy = mock_post_policy.call_args[0][0]
        assert policy["name"] == "test-policy"
        assert policy["policyItems"][0]["groups"] == ["group1"]
        assert len(policy["policyItems"][0]["accesses"]) == 3


class TestPodTemplate:
    """Test cases for pod_template step."""
    
    def test_build_pod_template(self):
        """Test building pod template."""
        env_config = {
            "env-configs": {
                "S3_AUTHORIZER_SERVER_BASE_URL": "https://test.example.com",
                "S3_ENDPOINT_URL": "https://minio.test.com",
                "HIVE_ENDPOINT_URL": "thrift://hive.test.com:9083"
            }
        }
        
        template = build_pod_template(
            tenant_name="t-55547-test",
            namespace="t-55547-test",
            secret_path="test/secret/path",
            env_config=env_config
        )
        
        assert template["kind"] == "Pod"
        assert template["metadata"]["namespace"] == "t-55547-test"
        
        # Check env variables
        env_vars = {env["name"]: env["value"] for env in template["spec"]["containers"][0]["env"]}
        assert env_vars["S3_AUTHORIZER_SERVER_BASE_URL"] == "https://test.example.com"
        assert env_vars["S3_ENDPOINT_URL"] == "https://minio.test.com"
        assert env_vars["HIVE_ENDPOINT_URL"] == "thrift://hive.test.com:9083"
    
    @patch('steps.pod_template.upload_to_minio')
    @patch('steps.pod_template.build_pod_template')
    def test_generate_and_upload_pod_template(
        self,
        mock_build,
        mock_upload,
        tmp_path
    ):
        """Test generating and uploading pod template."""
        mock_build.return_value = {"kind": "Pod"}
        env_config = {
            "platform-common-bucket": "test-bucket",
            "airflow-prefix": "test/prefix",
            "env-configs": {}
        }
        
        generate_and_upload_pod_template(
            tenant_name="t-55547-test",
            namespace="t-55547-test",
            secret_path="test/secret/path",
            output_dir=tmp_path,
            env="sit",
            env_config=env_config
        )
        
        mock_build.assert_called_once()
        mock_upload.assert_called_once()


class TestTrinoResourceGroup:
    """Test cases for trino_resource_group step."""
    
    @patch('steps.trino_resource_group.requests.get')
    @patch('steps.trino_resource_group.requests.post')
    @patch.dict('os.environ', {
        'TRINO_USER': 'test_user',
        'TRINO_PASSWORD': 'test_pass',
        'TRINO_ENDPOINT': 'https://trino.test.com'
    })
    def test_configure_trino_resource_group_new(
        self,
        mock_post,
        mock_get
    ):
        """Test configuring Trino resource group for new tenant."""
        # Mock get resource group - not found
        mock_get.return_value.status_code = 200
        mock_get.return_value.json.return_value = []
        mock_get.return_value.raise_for_status = Mock()
        
        # Mock create resource group
        mock_post.return_value.status_code = 200
        mock_post.return_value.raise_for_status = Mock()
        
        # Mock get resource group after creation
        mock_get.side_effect = [
            MagicMock(status_code=200, json=lambda: [], raise_for_status=Mock()),
            MagicMock(status_code=200, json=lambda: [{"name": "t-55547-test", "resourceGroupId": "123"}], raise_for_status=Mock())
        ]
        
        configure_trino_resource_group(
            tenant_name="t-55547-test",
            noninteractive_owners=["group1"],
            interactive_owners=["user1"]
        )
        
        # Verify API calls were made
        assert mock_get.call_count >= 1
        assert mock_post.call_count >= 1


class TestYuniKornQueue:
    """Test cases for yunikorn_queue step."""
    
    @patch('steps.yunikorn_queue.client.CoreV1Api')
    @patch('steps.yunikorn_queue.load_k8s_config')
    def test_update_yunikorn_queue(
        self,
        mock_load_config,
        mock_core_api
    ):
        """Test updating YuniKorn queue."""
        mock_v1 = MagicMock()
        mock_core_api.return_value = mock_v1
        
        # Mock ConfigMap
        mock_cm = MagicMock()
        mock_cm.data = {
            "queues.yaml": """
partitions:
  - name: default
    queues:
      - name: root
        queues: []
"""
        }
        mock_v1.read_namespaced_config_map.return_value = mock_cm
        mock_v1.replace_namespaced_config_map.return_value = None
        
        update_yunikorn_queue(
            tenant_name="t-55547-test",
            job_queue={"cpu": "4", "memory": "8Gi"}
        )
        
        # Verify ConfigMap was updated
        mock_v1.replace_namespaced_config_map.assert_called_once()


