"""
GDP Tenant Onboarding Pipeline - Python Implementation

Main package for tenant onboarding automation.
"""

