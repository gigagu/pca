# Tools

This directory contains utility tools for the GDP Tenant Onboarding Pipeline.

## Batch Onboarding Processor

Batch tenant onboarding processing tool for handling multiple tenant onboarding requests.

### Directory Structure

The tool expects the following directory structure:
```
t1_onboarding_request/
  tenant1/
    tenant-onboarding.yaml
    ranger-access.yaml (optional)
  tenant2/
    tenant-onboarding.yaml
    ranger-access.yaml (optional)
```

### Usage

```bash
# Run from project root
python src/tools/batch_onboarding.py --base-dir t1_onboarding_request --env sit

# Run from tools directory
cd src/tools
python batch_onboarding.py --base-dir ../../t1_onboarding_request --env sit
```

### Command Line Arguments

| Argument | Required | Description | Default |
|----------|----------|-------------|---------|
| `--base-dir` | ✅ Yes | Base directory containing tenant subdirectories | - |
| `--env` | ❌ No | Environment name (sit or prod) | `sit` |
| `--dry-run` | ❌ No | Run in dry-run mode | `False` |
| `--continue-on-error` | ❌ No | Continue processing other tenants if one fails | `False` |

### Examples

```bash
# Basic usage
python batch_onboarding.py --base-dir t1_onboarding_request --env sit

# Dry-run mode
python batch_onboarding.py --base-dir t1_onboarding_request --env sit --dry-run

# Continue on error
python batch_onboarding.py --base-dir t1_onboarding_request --env sit --continue-on-error
```

### Processing Results

The script will display:
- Processing status (success/failure) for each tenant
- Final processing summary
- Error messages for failed tenants
