# Pod Template Generator

独立工具，用于从 `manifest.yml` 文件生成 Spark Pod 模板 YAML 文件。该工具可以独立于完整的 onboarding 流程使用，专门用于生成 Kubernetes Pod 模板配置。

## 功能特性

- 📝 从 `manifest.yml` 文件读取平台配置
- 🔄 为每个 `platform-config` 条目自动生成 Pod 模板
- 🎯 自动生成租户名称和命名空间
- 🔐 集成 Vault 密钥注入配置
- 📦 支持批量生成多个 Pod 模板
- 💾 输出标准 Kubernetes YAML 格式

## 安装要求

### Python 版本
- Python 3.6+

### 依赖包
```bash
pip install pyyaml
```

或者从项目根目录安装所有依赖：
```bash
pip install -r ../requirements.txt
```

## 使用方法

### 基本用法

```bash
cd python/src/tools
python pod_template_generator.py --manifest ../../onboarding_manifest/manifest.yml
```

### 指定输出目录

```bash
python pod_template_generator.py \
    --manifest ../../onboarding_manifest/manifest.yml \
    --output-dir ./generated_templates
```

### 同时打印到标准输出

```bash
python pod_template_generator.py \
    --manifest ../../onboarding_manifest/manifest.yml \
    --output-dir ./output \
    --print
```

### 从项目根目录运行

```bash
python python/src/tools/pod_template_generator.py \
    --manifest python/onboarding_manifest/manifest.yml \
    --output-dir ./output
```

## 命令行参数

| 参数 | 必需 | 说明 | 默认值 |
|------|------|------|--------|
| `--manifest` | ✅ 是 | manifest.yml 文件路径 | - |
| `--output-dir` | ❌ 否 | 输出目录路径 | `./output` |
| `--print` | ❌ 否 | 同时打印 YAML 到标准输出 | `False` |

## Manifest 文件格式

工具期望的 `manifest.yml` 文件应包含 `platform-config` 数组，每个条目需要以下字段：

### 必需字段

- `itam`: ITAM 编号（整数）
- `tenant`: 租户名称（字符串）
- `tenant-short-name`: 租户短名称（字符串）

### 可选字段

- `namespace`: 命名空间后缀（字符串，默认为 `"default"`）
- `hcv-secret-path`: Vault 密钥路径（字符串，用于 S3 授权器凭证）

### 示例 Manifest

```yaml
platform-config:
  - itam: 55547
    tenant: gdpapp
    tenant-short-name: app
    namespace: analytics
    hcv-secret-path: "gdp/data/s3-authorizer/tenant/app"
  - itam: 55547
    tenant: another-tenant
    tenant-short-name: tenant2
    namespace: default
    hcv-secret-path: "gdp/data/s3-authorizer/tenant/tenant2"
```

## 输出格式

### 文件命名规则

生成的 Pod 模板文件命名格式为：
```
podtemplate-{tenant_name}.yaml
```

其中 `tenant_name` 的生成规则为：
```
t-{itam}-{tenant}-{tenant-short-name}
```

例如：
- `itam: 55547`, `tenant: gdpapp`, `tenant-short-name: app` 
- → 生成文件：`podtemplate-t-55547-gdpapp-app.yaml`

### 命名空间生成规则

Pod 模板中的命名空间生成规则为：
```
{tenant_name}-{namespace_suffix}
```

例如：
- `tenant_name: t-55547-gdpapp-app`, `namespace: analytics`
- → 命名空间：`t-55547-gdpapp-app-analytics`

## 生成的 Pod 模板特性

生成的 Pod 模板包含以下配置：

### 调度器配置
- **调度器**: `yunikorn`
- **队列**: 自动设置为租户名称
- **任务组**: `sched-style`

### 安全配置
- **运行用户**: `10000`
- **运行组**: `10000`
- **补充组**: `[10000]`
- **非 root 运行**: `true`
- **禁止权限提升**: `true`
- **删除所有能力**: `true`
- **Seccomp 配置**: `RuntimeDefault`

### Vault 集成
- **Vault Agent 注入**: 启用
- **服务账户**: `vault-auth`
- **角色名称**: `55547_global_app_k8s_{namespace}_role`
- **S3 授权器密钥**: 从 `hcv-secret-path` 注入

### 环境变量
- `POD_NAME`: Pod 名称（从 metadata.name 获取）
- `S3_AUTHORIZER_AUTH_FILE`: S3 授权器认证文件路径
- `HIVE_ENDPOINT_URL`: Hive Metastore 端点
- `S3_AUTHORIZER_SERVER_BASE_URL`: S3 授权器服务器地址
- `S3_ENDPOINT_URL`: MinIO 端点地址
- `AWS_ACCESS_KEY`: `NO_NEED`（使用 Vault 注入的凭证）
- `AWS_SECRET_KEY`: `NO_NEED`（使用 Vault 注入的凭证）
- `DATAHUB_REST_TOKEN`: 从 Secret `datahub-credential` 获取
- `DATAHUB_REST_ENDPOINT`: 从 Secret `datahub-credential` 获取

### 卷挂载
- `gdp-truststore-volume`: GDP 信任存储（`/etc/gdp/ssl`）
- `k8s-sa-token`: Kubernetes 服务账户令牌
- `s3auth-client-certs-vol`: S3 授权器客户端证书

### 资源限制
- **请求**:
  - CPU: `1`
  - 内存: `1Gi`
- **限制**:
  - CPU: `1`
  - 内存: `2Gi`

## 使用示例

### 示例 1: 基本生成

```bash
cd python/src/tools
python pod_template_generator.py \
    --manifest ../../onboarding_manifest/CEMSCOMP_ranger-access.yaml
```

输出：
```
2024-01-01 10:00:00 - INFO - Successfully generated 1 pod template(s):
2024-01-01 10:00:00 - INFO -   - output/podtemplate-t-55547-cemscomp-comp.yaml
```

### 示例 2: 自定义输出目录并打印

```bash
python pod_template_generator.py \
    --manifest ../../onboarding_manifest/manifest.yml \
    --output-dir ./my_templates \
    --print
```

### 示例 3: 处理多个平台配置

如果 manifest 包含多个 `platform-config` 条目，工具会为每个条目生成一个 Pod 模板：

```yaml
platform-config:
  - itam: 55547
    tenant: tenant1
    tenant-short-name: t1
  - itam: 55547
    tenant: tenant2
    tenant-short-name: t2
```

将生成：
- `podtemplate-t-55547-tenant1-t1.yaml`
- `podtemplate-t-55547-tenant2-t2.yaml`

## 错误处理

### 常见错误

1. **Manifest 文件不存在**
   ```
   ERROR - Manifest file not found: /path/to/manifest.yml
   ```
   - 检查文件路径是否正确
   - 确保使用绝对路径或正确的相对路径

2. **缺少必需字段**
   ```
   WARNING - Skipping platform-config[0] - missing fields: itam, tenant
   ```
   - 检查 manifest 文件中的 `platform-config` 条目
   - 确保包含 `itam`、`tenant` 和 `tenant-short-name` 字段

3. **没有 platform-config**
   ```
   ERROR - No platform-config found in manifest
   ```
   - 确保 manifest 文件包含 `platform-config` 键
   - 检查 YAML 格式是否正确

4. **YAML 解析错误**
   ```
   ERROR - Failed to parse manifest: ...
   ```
   - 检查 YAML 语法是否正确
   - 使用 YAML 验证工具检查文件格式

## 与完整流程的关系

该工具是完整 onboarding 流程中 **Step 7**（Pod 模板生成）的独立实现。主要区别：

| 特性 | 独立工具 | 完整流程 |
|------|---------|---------|
| 输入 | manifest.yml | manifest.yml |
| 输出 | 本地 YAML 文件 | 本地文件 + MinIO 上传 |
| 依赖 | 仅需 pyyaml | 需要完整依赖（K8s、MinIO 等） |
| 用途 | 仅生成模板 | 完整自动化流程 |

## 注意事项

1. **独立运行**: 该工具不依赖 Kubernetes 集群或 MinIO 服务，可以离线运行
2. **文件覆盖**: 如果输出目录中已存在同名文件，将被覆盖
3. **字段验证**: 缺少必需字段的 `platform-config` 条目会被跳过，不会导致整个流程失败
4. **命名空间默认值**: 如果未指定 `namespace`，将使用 `"default"` 作为后缀

## 相关文件

- **完整流程**: `../main.py` - 完整的租户 onboarding 流程
- **Pod 模板模块**: `../steps/pod_template.py` - 流程中的 Pod 模板生成步骤
- **示例 Manifest**: `../../onboarding_manifest/` - 示例 manifest 文件

## 许可证

与主项目保持一致。

