"""
MinIO bucket creation module.

This module handles creation of MinIO object storage buckets.
"""
import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)


def create_minio_buckets(buckets: List[Dict[str, Any]]) -> None:
    """
    Create MinIO buckets for tenant.
    
    This mirrors the Go implementation in pkg/tenant/minio.go:CreateBucket
    
    Args:
        buckets: List of bucket configurations
    """
    from minio import Minio
    from minio.error import S3Error
    # Import from parent package
    import sys
    import os
    parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)
    from utils.utils import get_minio_credentials
    
    if not buckets:
        logger.info("No buckets to create")
        return
    
    endpoint, access_key, secret_key = get_minio_credentials()
    
    # Initialize MinIO client
    client = Minio(
        endpoint,
        access_key=access_key,
        secret_key=secret_key,
        secure=True
    )
    
    for bucket_config in buckets:
        bucket_name = bucket_config.get("name")
        location = bucket_config.get("location", "ap-southeast-1")
        
        if not bucket_name:
            logger.warning("Skipping bucket with no name")
            continue
        
        try:
            # Check if bucket exists
            if client.bucket_exists(bucket_name):
                logger.info(f"Bucket {bucket_name} already exists")
                continue
            
            # Create bucket
            client.make_bucket(bucket_name, location=location)
            logger.info(f"Bucket {bucket_name} created in region {location}")
            
        except S3Error as e:
            logger.error(f"Failed to create bucket {bucket_name}: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error creating bucket {bucket_name}: {e}")
            raise

