"""
Kubernetes resources creation module.

This module handles creation of Namespace, ResourceQuota, and RBAC resources.
"""
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


def create_k8s_resources(
    tenant_name: str,
    namespace: str,
    resource_quotas: Dict[str, Any],
    noninteractive_owners: List[str],
    noninteractive_viewers: List[str]
) -> None:
    """
    Create Kubernetes resources: Namespace, ResourceQuota, Roles, RoleBindings.
    
    This mirrors the Go implementation in pkg/tenant/k8s.go:Apply
    
    Args:
        tenant_name: Full tenant name
        namespace: Namespace name
        resource_quotas: Resource quota configuration
        noninteractive_owners: List of non-interactive owner groups
        noninteractive_viewers: List of non-interactive viewer groups
    """
    from kubernetes import client
    from kubernetes.client.rest import ApiException
    # Import from parent package
    import sys
    import os
    parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)
    from utils.utils import load_k8s_config
    
    load_k8s_config()
    v1 = client.CoreV1Api()
    rbac_v1 = client.RbacAuthorizationV1Api()
    
    # 1. Create Namespace
    try:
        ns_body = client.V1Namespace(
            metadata=client.V1ObjectMeta(
                name=namespace,
                labels={"tenant": tenant_name}
            )
        )
        v1.create_namespace(body=ns_body)
        logger.info(f"Namespace {namespace} created")
    except ApiException as e:
        if e.status == 409:  # Already exists
            logger.info(f"Namespace {namespace} already exists")
        else:
            logger.error(f"Failed to create namespace: {e}")
            raise
    
    # 2. Create ResourceQuota
    try:
        cpu = resource_quotas.get("cpu", "0")
        memory = resource_quotas.get("memory", "0")
        
        quota_body = client.V1ResourceQuota(
            metadata=client.V1ObjectMeta(
                name="gdp-tenant-quota",
                namespace=namespace
            ),
            spec=client.V1ResourceQuotaSpec(
                hard={
                    "cpu": cpu,
                    "memory": memory
                }
            )
        )
        v1.create_namespaced_resource_quota(namespace=namespace, body=quota_body)
        logger.info(f"ResourceQuota created in namespace {namespace}")
    except ApiException as e:
        if e.status == 409:
            logger.info(f"ResourceQuota already exists in namespace {namespace}")
        else:
            logger.error(f"Failed to create ResourceQuota: {e}")
            raise
    
    # 3. Create View Role
    view_role_name = f"{tenant_name}-view"
    try:
        role_body = client.V1Role(
            metadata=client.V1ObjectMeta(
                name=view_role_name,
                namespace=namespace
            ),
            rules=[
                client.V1PolicyRule(
                    api_groups=[""],
                    resources=["pods"],
                    verbs=["get", "list", "watch"]
                ),
                client.V1PolicyRule(
                    api_groups=[""],
                    resources=["pods/log"],
                    verbs=["get", "list", "watch"]
                ),
                client.V1PolicyRule(
                    api_groups=["batch"],
                    resources=["jobs"],
                    verbs=["get", "list"]
                ),
                client.V1PolicyRule(
                    api_groups=["events.k8s.io"],
                    resources=["events"],
                    verbs=["get", "list", "watch"]
                ),
            ]
        )
        rbac_v1.create_namespaced_role(namespace=namespace, body=role_body)
        logger.info(f"Role {view_role_name} created")
    except ApiException as e:
        if e.status == 409:
            logger.info(f"Role {view_role_name} already exists")
        else:
            logger.error(f"Failed to create role: {e}")
            raise
    
    # 4. Create View RoleBinding
    # Group name pattern: suz1-apps-gdp-{tenantShortName}-view
    tenant_short = tenant_name.replace("t-", "").split("-")[-1] if tenant_name.startswith("t-") else tenant_name
    group_name = f"suz1-apps-gdp-{tenant_short}-view"
    
    try:
        role_binding_body = client.V1RoleBinding(
            metadata=client.V1ObjectMeta(
                name=view_role_name,
                namespace=namespace
            ),
            role_ref=client.V1RoleRef(
                api_group="rbac.authorization.k8s.io",
                kind="Role",
                name=view_role_name
            ),
            subjects=[
                client.V1Subject(
                    kind="Group",
                    name=group_name
                )
            ]
        )
        rbac_v1.create_namespaced_role_binding(namespace=namespace, body=role_binding_body)
        logger.info(f"RoleBinding {view_role_name} created for group {group_name}")
    except ApiException as e:
        if e.status == 409:
            logger.info(f"RoleBinding {view_role_name} already exists")
        else:
            logger.error(f"Failed to create role binding: {e}")
            raise
    
    # 5. Create Spark Job Role
    try:
        spark_role_body = client.V1Role(
            metadata=client.V1ObjectMeta(
                name="spark-job-role",
                namespace=namespace
            ),
            rules=[
                client.V1PolicyRule(
                    api_groups=[""],
                    resources=["pods", "pods/exec"],
                    verbs=["create", "get", "list", "watch", "delete"]
                ),
                client.V1PolicyRule(
                    api_groups=[""],
                    resources=["pods/log"],
                    verbs=["get", "list", "watch"]
                ),
                client.V1PolicyRule(
                    api_groups=[""],
                    resources=["configmaps"],
                    verbs=["create", "delete", "get", "list", "watch"]
                ),
                client.V1PolicyRule(
                    api_groups=[""],
                    resources=["persistentvolumeclaims"],
                    verbs=["create", "get", "list", "watch", "delete"]
                ),
            ]
        )
        rbac_v1.create_namespaced_role(namespace=namespace, body=spark_role_body)
        logger.info("Spark job role created")
    except ApiException as e:
        if e.status == 409:
            logger.info("Spark job role already exists")
        else:
            logger.error(f"Failed to create spark job role: {e}")
            raise
    
    # 6. Create Spark Job RoleBinding
    try:
        spark_binding_body = client.V1RoleBinding(
            metadata=client.V1ObjectMeta(
                name="sparkjob-binding",
                namespace=namespace
            ),
            role_ref=client.V1RoleRef(
                api_group="rbac.authorization.k8s.io",
                kind="Role",
                name="spark-job-role"
            ),
            subjects=[
                client.V1Subject(
                    kind="ServiceAccount",
                    name="vault-auth",
                    namespace=namespace
                ),
                client.V1Subject(
                    kind="ServiceAccount",
                    name="gdp-airflow-worker",
                    namespace="gdp-system"
                ),
                client.V1Subject(
                    kind="ServiceAccount",
                    name="gdp-airflow-webserver",
                    namespace="gdp-system"
                ),
            ]
        )
        rbac_v1.create_namespaced_role_binding(namespace=namespace, body=spark_binding_body)
        logger.info("Spark job role binding created")
    except ApiException as e:
        if e.status == 409:
            logger.info("Spark job role binding already exists")
        else:
            logger.error(f"Failed to create spark job role binding: {e}")
            raise

