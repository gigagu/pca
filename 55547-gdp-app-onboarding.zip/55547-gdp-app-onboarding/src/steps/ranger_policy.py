"""
Ranger policy configuration module.

This module handles creation of Apache Ranger access policies.
"""
import logging
import os
from typing import List, Dict, Any

import requests
import urllib3

# Disable SSL warnings for self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)


def apply_ranger_policies(tenant_name: str, ranger_policies: List[Dict[str, Any]]) -> None:
    """
    Apply Ranger policies for tenant schemas.
    
    This mirrors the Go implementation in pkg/tenant/ranger.go:Apply
    
    Args:
        tenant_name: Full tenant name
        ranger_policies: List of Ranger policy configurations
    """
    if not ranger_policies:
        logger.info("No Ranger policies to apply")
        return
    
    for policy_config in ranger_policies:
        schema_name = policy_config.get("schema_name")
        schema_path = policy_config.get("schema_path", "")
        admin_groups = policy_config.get("schema_admin", [])
        viewer_groups = policy_config.get("schema_viewer", [])
        
        if not schema_name:
            logger.warning("Skipping policy with no schema_name")
            continue
        
        # Remove s3a:// prefix if present
        if schema_path.startswith("s3a://"):
            schema_path = schema_path[4:]  # Remove "s3a"
        
        db_name = schema_name
        
        # Apply all 6 policies
        try:
            create_s3_admin_policy(tenant_name, schema_name, schema_path, admin_groups)
            create_table_admin_policy(tenant_name, schema_name, db_name, admin_groups)
            create_s3_viewer_policy(tenant_name, db_name, schema_path, viewer_groups)
            create_table_viewer_policy(tenant_name, db_name, viewer_groups)
            create_trino_table_admin_policy(tenant_name, schema_name, admin_groups)
            create_trino_table_viewer_policy(tenant_name, schema_name, viewer_groups)
            logger.info(f"All Ranger policies applied for schema {schema_name}")
        except Exception as e:
            logger.error(f"Failed to apply Ranger policies for {schema_name}: {e}")
            raise


def post_policy(policy: Dict[str, Any], func_name: str) -> None:
    """Post a policy to Ranger API."""
    base_url = os.getenv(
        "RANGER_BASE_URL",
        "https://ranger-prd.sked011.55547.app.standardchartered.com"
    )
    url = f"{base_url}/service/plugins/policies/apply"
    
    username = os.getenv("RANGER_USER")
    password = os.getenv("RANGER_PASS")
    
    if not username or not password:
        raise ValueError("RANGER_USER and RANGER_PASS environment variables required")
    
    headers = {"Content-Type": "application/json"}
    
    try:
        response = requests.post(
            url,
            json=policy,
            headers=headers,
            auth=(username, password),
            verify=False,
            timeout=30
        )
        response.raise_for_status()
        logger.debug(f"{func_name} policy applied successfully")
    except Exception as e:
        logger.error(f"{func_name} failed: {e}")
        raise


def create_s3_admin_policy(tenant_name: str, schema_name: str, schema_path: str, admin_groups: List[str]) -> None:
    """Create S3 admin policy."""
    policy = {
        "isEnabled": True,
        "service": "fors3",
        "name": f"admin-{tenant_name}-{schema_name}",
        "policyType": 0,
        "policyPriority": 0,
        "isAuditEnabled": True,
        "resources": {
            "path": {
                "values": [schema_path],
                "isExcludes": False,
                "isRecursive": True
            }
        },
        "policyItems": [{
            "accesses": [
                {"type": "read", "isAllowed": True},
                {"type": "write", "isAllowed": True},
                {"type": "execute", "isAllowed": True}
            ],
            "groups": admin_groups,
            "delegateAdmin": False
        }],
        "serviceType": "hdfs",
        "isDenyAllElse": False
    }
    post_policy(policy, "CreateS3AdminPolicy")


def create_table_admin_policy(tenant_name: str, schema_name: str, db_name: str, admin_groups: List[str]) -> None:
    """Create Hive table admin policy."""
    policy = {
        "isEnabled": True,
        "service": "hive-dev-policy",
        "name": f"admin-{tenant_name}-{schema_name}-tables",
        "policyType": 0,
        "policyPriority": 0,
        "description": "Policy for admin - database",
        "isAuditEnabled": True,
        "resources": {
            "database": {
                "values": [db_name],
                "isRecursive": False
            },
            "table": {
                "values": ["*"],
                "isRecursive": False
            }
        },
        "policyItems": [{
            "accesses": [
                {"type": "select", "isAllowed": True},
                {"type": "update", "isAllowed": True},
                {"type": "create", "isAllowed": True},
                {"type": "drop", "isAllowed": True},
                {"type": "alter", "isAllowed": True},
                {"type": "all", "isAllowed": True}
            ],
            "groups": admin_groups,
            "delegateAdmin": True
        }],
        "serviceType": "hive",
        "isDenyAllElse": False
    }
    post_policy(policy, "CreateTableAdminPolicy")


def create_s3_viewer_policy(tenant_name: str, db_name: str, schema_path: str, viewer_groups: List[str]) -> None:
    """Create S3 viewer policy."""
    policy = {
        "isEnabled": True,
        "service": "fors3",
        "name": f"view-{tenant_name}-{db_name}-path",
        "policyType": 0,
        "policyPriority": 0,
        "isAuditEnabled": True,
        "resources": {
            "path": {
                "values": [schema_path],
                "isExcludes": False,
                "isRecursive": True
            }
        },
        "policyItems": [{
            "accesses": [
                {"type": "read", "isAllowed": True}
            ],
            "groups": viewer_groups,
            "delegateAdmin": False
        }],
        "serviceType": "hdfs",
        "isDenyAllElse": False
    }
    post_policy(policy, "CreateS3ViewerPolicy")


def create_table_viewer_policy(tenant_name: str, db_name: str, viewer_groups: List[str]) -> None:
    """Create Hive table viewer policy."""
    policy = {
        "isEnabled": True,
        "service": "hive-dev-policy",
        "name": f"view-{tenant_name}-{db_name}-tables",
        "policyType": 0,
        "policyPriority": 0,
        "description": "Policy for viewer - database",
        "isAuditEnabled": True,
        "resources": {
            "database": {
                "values": [db_name],
                "isRecursive": False
            },
            "table": {
                "values": ["*"],
                "isRecursive": False
            }
        },
        "policyItems": [{
            "accesses": [
                {"type": "select", "isAllowed": True}
            ],
            "groups": viewer_groups,
            "delegateAdmin": False
        }],
        "serviceType": "hive",
        "isDenyAllElse": False
    }
    post_policy(policy, "CreateTableViewerPolicy")


def create_trino_table_admin_policy(tenant_name: str, schema_name: str, admin_groups: List[str]) -> None:
    """Create Trino table admin policy."""
    policy = {
        "isEnabled": True,
        "service": "trino_prod",
        "name": f"admin-{tenant_name}-{schema_name}-tables",
        "policyType": 0,
        "policyPriority": 0,
        "description": "Policy for admin - database",
        "isAuditEnabled": True,
        "resources": {
            "schema": {
                "values": [schema_name],
                "isRecursive": False
            },
            "catalog": {
                "values": ["gdp_global"],
                "isRecursive": False
            },
            "column": {
                "values": ["*"],
                "isRecursive": False
            },
            "table": {
                "values": ["*"],
                "isRecursive": False
            }
        },
        "policyItems": [{
            "accesses": [
                {"type": "select", "isAllowed": True},
                {"type": "insert", "isAllowed": True},
                {"type": "create", "isAllowed": True},
                {"type": "drop", "isAllowed": True},
                {"type": "delete", "isAllowed": True},
                {"type": "all", "isAllowed": True}
            ],
            "groups": admin_groups,
            "delegateAdmin": True
        }],
        "serviceType": "trino",
        "isDenyAllElse": False
    }
    post_policy(policy, "CreateTrinoTableAdminPolicy")


def create_trino_table_viewer_policy(tenant_name: str, schema_name: str, viewer_groups: List[str]) -> None:
    """Create Trino table viewer policy."""
    policy = {
        "isEnabled": True,
        "service": "trino_prod",
        "name": f"viewer-{tenant_name}-{schema_name}-tables",
        "policyType": 0,
        "policyPriority": 0,
        "description": "Policy for viewer - database",
        "isAuditEnabled": True,
        "resources": {
            "schema": {
                "values": [schema_name],
                "isRecursive": False
            },
            "catalog": {
                "values": ["gdp_global"],
                "isRecursive": False
            },
            "column": {
                "values": ["*"],
                "isRecursive": False
            },
            "table": {
                "values": ["*"],
                "isRecursive": False
            }
        },
        "policyItems": [{
            "accesses": [
                {"type": "select", "isAllowed": True},
                {"type": "show", "isAllowed": True}
            ],
            "groups": viewer_groups,
            "delegateAdmin": True
        }],
        "serviceType": "trino",
        "isDenyAllElse": False
    }
    post_policy(policy, "CreateTrinoTableViewerPolicy")

