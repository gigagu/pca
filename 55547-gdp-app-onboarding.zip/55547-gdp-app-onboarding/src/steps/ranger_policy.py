"""
Ranger policy configuration module.

This module handles creation of Apache Ranger access policies.
"""
import json
import logging
import os
from typing import List, Dict, Any

import requests
import urllib3

# Disable SSL warnings for self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

def normalize_to_list(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        return [value]
    return value

def apply_ranger_policies(
    tenant_name: str,
    ranger_policies: Dict[str, Any],
    platform_bucket: str,
    airflow_prefix: str,
    env_config: Dict[str, Any]
) -> None:
    """
    Apply Ranger policies for tenant.
    
    For each tenant, create three separate policies:
    1. t-tenant-common-readonly: readonly access for common-group from common-object-store
       - Paths from config: common-readonly paths
    2. t-tenant-common-readwrite: readwrite access for common-group from common-object-store
       - Paths from config: common-readwrite paths
    3. app-{tenant_name}-fullaccess-S3: readwrite access for admin-group from object-store-buckets and airflow-object-store
       - Paths: /{object-store-buckets.name} and /{platform_bucket}/{airflow_prefix}/{tenant_name}
    
    Args:
        tenant_name: Full tenant name
        ranger_policies: Ranger policy configuration from manifest
        platform_bucket: Platform common bucket name
        airflow_prefix: Airflow prefix path
        env_config: Environment configuration dictionary
    """
    if not ranger_policies:
        logger.info("No Ranger policies to apply")
        return
    
    # Extract bucket configurations
    object_store_buckets = ranger_policies.get("object-store-buckets", [])
    airflow_object_store = ranger_policies.get("airflow-object-store", {})
    # common_object_store = ranger_policies.get("common-object-store", {})
    
    # Get common-group from common-object-store
    # common_groups = common_object_store.get("common-group", [])
    common_groups = normalize_to_list(airflow_object_store.get("admin-group", []))
    print(common_groups)

    # Get policy paths from config
    policy_paths_config = env_config.get("ranger-policy-paths", {})
    common_readonly_paths_template = policy_paths_config.get("common-readonly", [])
    common_readwrite_paths_template = policy_paths_config.get("common-readwrite", [])
    
    # Replace {platform-common-bucket} placeholder in policy paths
    def replace_placeholders(paths: List[str]) -> List[str]:
        return [path.replace("{platform-common-bucket}", platform_bucket) for path in paths]
    
    common_readonly_paths = replace_placeholders(common_readonly_paths_template)
    common_readwrite_paths = replace_placeholders(common_readwrite_paths_template)
    
    # Create Policy 1: t-tenant-common-readonly
    if common_groups and common_readonly_paths:
        readonly_policy_name = "t-tenant-common-readonly"
        create_s3_policy(
            policy_name=readonly_policy_name,
            paths=common_readonly_paths,
            groups=common_groups,
            access_types=["read"],
            ranger_base_url=env_config.get("env-configs", {}).get("RANGER_BASE_URL")
        )
        logger.info(f"Ranger readonly policy {readonly_policy_name} created for groups {common_groups}")
    
    # Create Policy 2: t-tenant-common-readwrite
    if common_groups and common_readwrite_paths:
        readwrite_policy_name = "t-tenant-common-readwrite"
        create_s3_policy(
            policy_name=readwrite_policy_name,
            paths=common_readwrite_paths,
            groups=common_groups,
            access_types=["read", "write", "execute"],
            ranger_base_url=env_config.get("env-configs", {}).get("RANGER_BASE_URL")
        )
        logger.info(f"Ranger readwrite policy {readwrite_policy_name} created for groups {common_groups}")
    
    # Collect admin groups from buckets and airflow
    admin_groups = []
    for bucket_config in object_store_buckets:
        bucket_admin_groups = normalize_to_list(bucket_config.get("admin-group", []))
        admin_groups.extend(bucket_admin_groups)
    
    airflow_admin_groups = normalize_to_list(airflow_object_store.get("admin-group", []))
    admin_groups.extend(airflow_admin_groups)
    
    # Remove duplicates while preserving order
    admin_groups = list(dict.fromkeys(admin_groups))
    
    # Collect paths for Policy 3: object-store-buckets and airflow path
    policy3_paths = []
    # Add paths for each object-store-bucket
    for bucket_config in object_store_buckets:
        bucket_name = bucket_config.get("name")
        if bucket_name:
            policy3_paths.append(f"/{bucket_name}")
    
    # Add airflow path
    airflow_path = f"/{platform_bucket}/{airflow_prefix}/{tenant_name}"
    policy3_paths.append(airflow_path)
    
    # Create Policy 3: app-{tenant_name}-fullaccess-S3
    if admin_groups and policy3_paths:
        admin_policy_name = f"app-{tenant_name}-fullaccess-S3"
        create_s3_policy(
            policy_name=admin_policy_name,
            paths=policy3_paths,
            groups=admin_groups,
            access_types=["read", "write", "execute"],
            ranger_base_url=env_config.get("env-configs", {}).get("RANGER_BASE_URL")
        )
        logger.info(f"Ranger admin policy {admin_policy_name} created for groups {admin_groups}")
    
    logger.info(f"All Ranger policies for tenant {tenant_name} created successfully")


def post_policy(policy: Dict[str, Any], func_name: str, ranger_base_url: str = None) -> None:
    """Post a policy to Ranger API."""
    url = f"{ranger_base_url}/service/plugins/policies/apply"
    
    username = os.getenv("RANGER_USER")
    password = os.getenv("RANGER_PASS")
    
    if not username or not password:
        raise ValueError("RANGER_USER and RANGER_PASS environment variables required")
    
    headers = {"Content-Type": "application/json"}
    
    try:
        response = requests.post(
            url,
            json=policy,
            headers=headers,
            auth=(username, password),
            verify=False,
            timeout=30
        )
        response.raise_for_status()
        logger.debug(f"{func_name} policy applied successfully")
    except Exception as e:
        logger.error(f"{func_name} failed: {e}\nResponse: {response.text}")
        raise


def create_s3_policy(
    policy_name: str,
    paths: List[str],
    groups: List[str],
    access_types: List[str],
    ranger_base_url: str = None
) -> None:
    """
    Create a single S3 policy with specified paths, groups, and access types.
    
    Args:
        policy_name: Policy name
        paths: List of S3 paths
        groups: List of groups to grant access
        access_types: List of access types (e.g., ["read"], ["read", "write", "execute"])
        ranger_base_url: Ranger base URL (optional, will use config or env var if not provided)
    """
    if not groups:
        logger.warning(f"No groups specified for policy {policy_name}, skipping")
        return
    
    if not paths:
        logger.warning(f"No paths specified for policy {policy_name}, skipping")
        return
    
    # Build access list
    accesses = [{"type": access_type, "isAllowed": True} for access_type in access_types]
    
    policy = {
        "isEnabled": True,
        "service": "fors3",
        "name": policy_name,
        "policyType": 0,
        "policyPriority": 0,
        "isAuditEnabled": True,
        "resources": {
            "path": {
                "values": paths,
                "isExcludes": False,
                "isRecursive": True
            }
        },
        "policyItems": [{
            "accesses": accesses,
            "groups": groups,
            "delegateAdmin": False
        }],
        "serviceType": "hdfs",
        "isDenyAllElse": False
    }
    print(json.dumps(policy, indent=2))
    
    post_policy(policy, f"CreateS3Policy-{policy_name}", ranger_base_url)
