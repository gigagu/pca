"""
GDPTenant Custom Resource creation module.

This module handles creation and management of GDPTenant CR in Kubernetes.
"""
import logging
import os
import sys
from typing import Dict, Any

from kubernetes import client, config, dynamic
from kubernetes.client import api_client
from kubernetes.client.rest import ApiException

# Import from parent package
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
from utils.utils import load_k8s_config

logger = logging.getLogger(__name__)


def create_gdptenant_cr(tenant_name: str, platform_config: Dict[str, Any]) -> None:
    """
    Create or update GDPTenant CR in Kubernetes.
    
    This mirrors the Go implementation in pkg/tenant/tenant.go:BuildTenant
    and pkg/k8s/tenant_manage.go:ApplyTenant
    
    Args:
        tenant_name: Full tenant name (e.g., t-55547-gdpapp-app)
        platform_config: Platform configuration from manifest
    """
    
    load_k8s_config()
    
    # Build GDPTenant CR spec
    cr_spec = {
        "apiVersion": "gdp.standardchartered.com/v1",
        "kind": "GDPTenant",
        "metadata": {
            "name": tenant_name,
            "namespace": "gdp-system"
        },
        "spec": {
            "tenant": platform_config.get("tenant"),
            "tenant-short-name": platform_config.get("tenant-short-name"),
            "itam": platform_config.get("itam"),
            "bc": platform_config.get("bc", ""),
            "namespace": platform_config.get("namespace", "default"),
            "target": platform_config.get("target", []),
            "resource-quotas": platform_config.get("resource-quotas", {}),
            "jobs-queue": platform_config.get("jobs-queue", {}),
            "object-store-buckets": platform_config.get("object-store-buckets", []),
            "ranger-policies": platform_config.get("ranger-policies", []),
            "tenant-noninteractive-owner": platform_config.get("tenant-noninteractive-owner", []),
            "tenant-noninteractive-viewer": platform_config.get("tenant-noninteractive-viewer", []),
            "tenant-interactive-owner": platform_config.get("tenant-interactive-owner", []),
            "tenant-interactive-viewer": platform_config.get("tenant-interactive-viewer", []),
        }
    }
    
    # Use dynamic client for CRD operations
    api_client_instance = api_client.ApiClient()
    dynamic_client = dynamic.DynamicClient(api_client_instance)
    
    # Get the resource for GDPTenant CRD
    api_version = "gdp.standardchartered.com/v1"
    kind = "GDPTenant"
    
    try:
        resource = dynamic_client.resources.get(api_version=api_version, kind=kind)
    except Exception as e:
        logger.error(f"Failed to get GDPTenant resource definition: {e}")
        logger.error("Make sure the GDPTenant CRD is installed in the cluster")
        raise
    
    try:
        # Try to get existing CR
        existing = resource.get(name=tenant_name, namespace="gdp-system")
        logger.info(f"GDPTenant CR {tenant_name} already exists, updating...")
        
        # Update existing CR
        existing["spec"] = cr_spec["spec"]
        resource.replace(body=existing, name=tenant_name, namespace="gdp-system")
        logger.info(f"GDPTenant CR {tenant_name} updated successfully")
        
    except Exception as e:
        # Check if it's a 404 (not found) error
        error_str = str(e)
        if "404" in error_str or "Not Found" in error_str:
            # Create new CR
            logger.info(f"Creating new GDPTenant CR {tenant_name}")
            resource.create(body=cr_spec, namespace="gdp-system")
            logger.info(f"GDPTenant CR {tenant_name} created successfully")
        else:
            logger.error(f"Failed to create/update GDPTenant CR: {e}")
            raise

