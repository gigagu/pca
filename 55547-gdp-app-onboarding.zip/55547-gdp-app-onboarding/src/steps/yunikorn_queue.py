"""
YuniKorn queue configuration module.

This module handles updating YuniKorn scheduler queue configuration.
"""
import logging
import os
import sys
from typing import Dict, Any

import yaml
from kubernetes import client
from kubernetes.client.rest import ApiException

# Import from parent package
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
from utils.utils import load_k8s_config

logger = logging.getLogger(__name__)


def update_yunikorn_queue(tenant_name: str, job_queue: Dict[str, Any]) -> None:
    """
    Update YuniKorn queue configuration for tenant.
    
    This mirrors the Go implementation in pkg/tenant/yunikorn.go:ApplyTenantQueue
    
    Args:
        tenant_name: Full tenant name
        job_queue: Job queue configuration with cpu and memory
    """
    
    load_k8s_config()
    v1 = client.CoreV1Api()
    
    namespace = "gdp-system"
    configmap_name = "yunikorn-configs"
    queue_key = "queues.yaml"
    
    # Get existing ConfigMap
    try:
        cm = v1.read_namespaced_config_map(name=configmap_name, namespace=namespace)
    except ApiException as e:
        logger.error(f"Failed to get YuniKorn ConfigMap: {e}")
        raise
    
    # Parse existing queue configuration
    queue_yaml = cm.data.get(queue_key, "")
    if not queue_yaml:
        logger.error(f"Queue configuration not found in ConfigMap {configmap_name}")
        raise ValueError("Queue configuration not found")
    
    config = yaml.safe_load(queue_yaml)
    
    # Find or create tenant queue
    cpu = job_queue.get("cpu", "4")
    memory = job_queue.get("memory", "8192")
    
    # Apply tenant queue (simplified - assumes default partition)
    if "partitions" in config and len(config["partitions"]) > 0:
        partition = config["partitions"][0]
        if "queues" in partition and len(partition["queues"]) > 0:
            root_queue = partition["queues"][0]
            if "queues" not in root_queue:
                root_queue["queues"] = []
            
            # Check if queue already exists
            queue_exists = False
            for q in root_queue["queues"]:
                if q.get("name") == tenant_name:
                    # Update existing queue
                    q["resources"] = {
                        "guaranteed": {
                            "memory": memory,
                            "vcore": cpu
                        },
                        "max": {
                            "memory": memory,
                            "vcore": cpu
                        }
                    }
                    queue_exists = True
                    logger.info(f"Updated existing queue {tenant_name}")
                    break
            
            if not queue_exists:
                # Add new queue
                new_queue = {
                    "name": tenant_name,
                    "submitacl": "*",
                    "resources": {
                        "guaranteed": {
                            "memory": memory,
                            "vcore": cpu
                        },
                        "max": {
                            "memory": memory,
                            "vcore": cpu
                        }
                    }
                }
                root_queue["queues"].append(new_queue)
                logger.info(f"Added new queue {tenant_name}")
    
    # Update ConfigMap
    updated_yaml = yaml.dump(config, default_flow_style=False, sort_keys=False)
    cm.data[queue_key] = updated_yaml
    
    try:
        v1.replace_namespaced_config_map(
            name=configmap_name,
            namespace=namespace,
            body=cm
        )
        logger.info(f"YuniKorn queue configuration updated for {tenant_name}")
    except ApiException as e:
        logger.error(f"Failed to update YuniKorn ConfigMap: {e}")
        raise

