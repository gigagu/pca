"""
Trino resource group configuration module.

This module handles creation and configuration of Trino resource groups and selectors.
"""
import logging
import base64
import os
from typing import List

import requests
import urllib3

# Disable SSL warnings for self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)


def configure_trino_resource_group(
    tenant_name: str,
    noninteractive_owners: List[str],
    interactive_owners: List[str]
) -> None:
    """
    Configure Trino resource group and selector for tenant.
    
    This mirrors the Go implementation in pkg/tenant/trino.go:Apply
    
    Args:
        tenant_name: Full tenant name
        noninteractive_owners: List of non-interactive owner groups
        interactive_owners: List of interactive owner groups
    """
    # Get Trino credentials
    username = os.getenv("TRINO_USER")
    password = os.getenv("TRINO_PASSWORD")
    
    if not username or not password:
        raise ValueError("TRINO_USER and TRINO_PASSWORD environment variables required")
    
    # Base64 encode credentials
    auth_string = f"{username}:{password}"
    encoded = base64.b64encode(auth_string.encode()).decode()
    
    # Trino endpoint from constants
    trino_endpoint = os.getenv(
        "TRINO_ENDPOINT",
        "https://trino-gw-prd.sked011.55547.app.standardchartered.com"
    )
    
    # Check if resource group exists
    group_id = get_resource_group(tenant_name, encoded, trino_endpoint)
    
    if not group_id:
        # Create new resource group
        logger.info(f"Creating Trino resource group for {tenant_name}")
        group_id = create_resource_group(tenant_name, encoded, trino_endpoint)
        
        # Create selector
        if noninteractive_owners:
            create_selector(group_id, noninteractive_owners[0], encoded, trino_endpoint)
    else:
        # Update existing selector
        logger.info(f"Trino resource group {tenant_name} already exists, updating selector")
        if noninteractive_owners:
            update_selector(group_id, noninteractive_owners[0], encoded, trino_endpoint)


def get_resource_group(tenant_name: str, encoded: str, endpoint: str) -> str:
    """Get resource group ID by name."""
    url = f"{endpoint}/trino/resourcegroup/read"
    headers = {"Authorization": f"Basic {encoded}"}
    
    try:
        response = requests.get(url, headers=headers, verify=False, timeout=30)
        response.raise_for_status()
        
        groups = response.json()
        for group in groups:
            if group.get("name") == tenant_name:
                group_id = group.get("resourceGroupId")
                return str(group_id) if group_id else ""
        
        return ""
    except Exception as e:
        logger.error(f"Failed to get resource groups: {e}")
        raise


def create_resource_group(tenant_name: str, encoded: str, endpoint: str) -> str:
    """Create a new Trino resource group."""
    url = f"{endpoint}/trino/resourcegroup/create"
    headers = {
        "Authorization": f"Basic {encoded}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "name": tenant_name,
        "softMemoryLimit": "30%",
        "maxQueued": 30,
        "softConcurrencyLimit": 20,
        "hardConcurrencyLimit": 20,
        "jmxExport": True,
        "parent": 1,
        "environment": "trinoskestg"
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers, verify=False, timeout=30)
        response.raise_for_status()
        
        # Get the created group ID
        group_id = get_resource_group(tenant_name, encoded, endpoint)
        logger.info(f"Resource group {tenant_name} created with ID {group_id}")
        return group_id
    except Exception as e:
        logger.error(f"Failed to create resource group: {e}")
        raise


def create_selector(group_id: str, user_regex: str, encoded: str, endpoint: str) -> None:
    """Create a selector for the resource group."""
    url = f"{endpoint}/trino/selector/create"
    headers = {
        "Authorization": f"Basic {encoded}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "resourceGroupId": group_id,
        "priority": 2,
        "userRegex": user_regex
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers, verify=False, timeout=30)
        response.raise_for_status()
        logger.info(f"Selector created for resource group {group_id}")
    except Exception as e:
        logger.error(f"Failed to create selector: {e}")
        raise


def update_selector(group_id: str, user_regex: str, encoded: str, endpoint: str) -> None:
    """Update an existing selector."""
    url = f"{endpoint}/trino/selector/update"
    headers = {
        "Authorization": f"Basic {encoded}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "resourceGroupId": group_id,
        "priority": 2,
        "userRegex": user_regex
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers, verify=False, timeout=30)
        response.raise_for_status()
        logger.info(f"Selector updated for resource group {group_id}")
    except Exception as e:
        logger.error(f"Failed to update selector: {e}")
        raise

