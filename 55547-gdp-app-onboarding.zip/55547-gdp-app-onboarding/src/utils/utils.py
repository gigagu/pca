"""
Utility functions for tenant onboarding pipeline.
"""
from typing import Dict, Any


def generate_tenant_name(itam: int, tenant: str, tenant_short_name: str) -> str:
    """
    Generate tenant name following the pattern: t-{itam}-{tenant}-{tenantShortName}
    
    This matches the Go implementation in pkg/tenant/tenant.go:142
    
    Args:
        itam: ITAM number
        tenant: Tenant name
        tenant_short_name: Tenant short name
        
    Returns:
        Generated tenant name (e.g., t-55547-gdpapp-app)
    """
    return f"t-{itam}-{tenant}-{tenant_short_name}"


def generate_namespace(tenant_name: str, namespace: str) -> str:
    """
    Generate namespace name following the pattern: {tenantName}-{namespace}
    
    This matches the Go implementation in pkg/tenant/tenant.go:156
    
    Args:
        tenant_name: Full tenant name
        namespace: Namespace suffix from manifest
        
    Returns:
        Generated namespace name (e.g., t-55547-gdpapp-app-analytics)
    """
    return f"{tenant_name}-{namespace}"


def load_k8s_config():
    """Load Kubernetes configuration."""
    try:
        from kubernetes import config
        try:
            config.load_incluster_config()
        except:
            config.load_kube_config()
    except ImportError:
        raise ImportError("kubernetes package not installed. Install with: pip install kubernetes")


def get_minio_credentials() -> tuple:
    """Get MinIO credentials from environment variables."""
    import os
    endpoint = os.getenv("MINIO_ENDPOINT")
    access_key = os.getenv("MINIO_ACCESS_KEY")
    secret_key = os.getenv("MINO_SECRET_KEY")  # Note: typo in env var name
    
    if not all([endpoint, access_key, secret_key]):
        raise ValueError("MinIO credentials not found in environment variables")
    
    return endpoint, access_key, secret_key

