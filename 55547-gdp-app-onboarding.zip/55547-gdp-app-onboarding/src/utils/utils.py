"""
Utility functions for tenant onboarding pipeline.
"""
import os
import yaml
from pathlib import Path
from typing import Dict, Any


def generate_tenant_name(tenant_itam: int, raw_tenant_name: str) -> str:
    """
    Generate tenant name following the pattern: t-{tenant_itam}-{raw_tenant_name}
    
    This matches the Go implementation in pkg/tenant/tenant.go:142
    
    Args:
        tenant_itam: ITAM number
        tenant_name: Tenant name
        
    Returns:
        Generated tenant name
    """
    return f"t-{tenant_itam}-{raw_tenant_name}"


def generate_namespace(tenant_name: str, namespace: str) -> str:
    """
    Generate namespace name following the pattern: {tenantName}-{namespace}
    
    This matches the Go implementation in pkg/tenant/tenant.go:156
    
    Args:
        tenant_name: Full tenant name
        namespace: Namespace suffix from manifest
        
    Returns:
        Generated namespace name (e.g., t-55547-gdpapp-app-analytics)
    """
    return f"{tenant_name}-{namespace}"


def load_k8s_config():
    """Load Kubernetes configuration."""
    try:
        from kubernetes import config
        try:
            config.load_incluster_config()
        except:
            config.load_kube_config()
    except ImportError:
        raise ImportError("kubernetes package not installed. Install with: pip install kubernetes")


def get_minio_credentials() -> tuple:
    """Get MinIO credentials from environment variables."""
    endpoint = os.getenv("MINIO_ENDPOINT")
    access_key = os.getenv("MINIO_ACCESS_KEY")
    secret_key = os.getenv("MINO_SECRET_KEY")  # Note: typo in env var name
    
    if not all([endpoint, access_key, secret_key]):
        raise ValueError("MinIO credentials not found in environment variables")
    
    return endpoint, access_key, secret_key


def load_env_config(env: str = "sit") -> Dict[str, Any]:
    """
    Load environment configuration from config/{env}.yml
    
    Args:
        env: Environment name (sit or prod)
        
    Returns:
        Dictionary containing environment configuration
    """
    config_dir = Path(__file__).parent.parent / "config"
    config_file = config_dir / f"{env}.yml"
    
    if not config_file.exists():
        raise ValueError(f"Config file not found: {config_file}")
    
    with config_file.open("r", encoding="utf-8") as f:
        config = yaml.safe_load(f)
    
    if not config:
        raise ValueError(f"Config file {config_file} is empty or invalid")
    
    return config

