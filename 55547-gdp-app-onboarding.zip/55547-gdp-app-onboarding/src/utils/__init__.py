"""
Utility functions for tenant onboarding pipeline.
"""

