# GDP Tenant Onboarding Technical Design Document

## 1. Overview

This document provides a comprehensive technical design for the GDP (Global Data Platform) Tenant Onboarding System. It details API interfaces, component integration steps, parameter specifications, and sample inputs for each component.

### 1.1 System Architecture

```
┌─────────────┐
│   Client    │ (Azure DevOps Pipeline / Manual)
│             │
│  platform.mf│ (YAML manifest)
└──────┬──────┘
       │ POST /v1/gdp/tenant/create (JSON)
       ▼
┌─────────────────────────────────────┐
│   GDP Tenant Onboarding API         │
│   Port: 6443                        │
│   (main.go + tenant.go)             │
└──────┬──────────────────────────────┘
       │
       ├─► GDPTenant CR (Kubernetes)
       ├─► Kubernetes Resources
       │   ├─ Namespace
       │   ├─ ResourceQuota
       │   └─ RBAC (Role, RoleBinding)
       ├─► YuniKorn Queue Configuration
       ├─► MinIO Bucket Creation
       ├─► Trino Resource Group & Selector
       ├─► Ranger Policies (6 policies)
       └─► Pod Template Upload (S3)
```

### 1.2 Core Components

- **Kubernetes**: Namespace, ResourceQuota, Role, RoleBinding
- **YuniKorn**: Queue scheduler configuration
- **MinIO**: Object storage bucket management
- **Trino**: Query engine resource groups and selectors
- **Ranger**: Data access policies for fine-grained access control

---

## 2. API Interface

### 2.1 Create Tenant API

**Endpoint**: `POST /v1/gdp/tenant/create`

**Content-Type**: `application/json`

**Port**: `6443`

**Request Body**: `AppManifest` (see Section 3.1)

**Response**:
- **Success (200 OK)**: 
```json
[
  {
    "tenantName": "t-55547-gdpapp-app",
    "namespace": "t-55547-gdpapp-app-analytics",
    "minioBuckets": [
      {
        "name": "gdpapp-raw",
        "bucket-size": "100Gi",
        "location": "ap-southeast-1"
      }
    ],
    "yunikornQueue": "t-55547-gdpapp-app"
  }
]
```

- **Error (400 Bad Request)**: JSON format error or field validation failure
- **Error (500 Internal Server Error)**: Backend processing error

**Implementation**: `pkg/tenant/tenant.go:86` - `CreateTenant()`

---

## 3. Request Model & Sample Input

### 3.1 AppManifest Structure

```json
{
  "meta-data": {
    "manifest-schema": "gdp-tenant",
    "manifest-version": "v1"
  },
  "platform-config": [
    {
      "cluster": "gdp-prod",
      "product": "example-app",
      "resilience-level": "standard",
      "target": ["prod"],
      "itam-name": "example-itam",
      "sbia": 1,
      "ibs": false,
      "lob": "TTO",
      "ito-unit": "ITO-UNIT-1",
      "itam": 55547,
      "bc": "BC1",
      "tenant": "gdpapp",
      "tenant-short-name": "app",
      "tenant-desc": "Example tenant description",
      "tenant-noninteractive-owner": ["suz1-apps-gdp-gdpapp-admin"],
      "tenant-noninteractive-viewer": ["suz1-apps-gdp-gdpapp-view"],
      "tenant-interactive-owner": ["suz1-apps-gdp-gdpapp-int-admin"],
      "tenant-interactive-viewer": ["suz1-apps-gdp-gdpapp-int-view"],
      "namespace": "analytics",
      "hcv-secret-path": "secret/data/gdpapp/creds",
      "jobs-queue": {
        "cpu": "4",
        "memory": "8192"
      },
      "resource-quotas": {
        "cpu": "8",
        "memory": "16384"
      },
      "object-store-buckets": [
        {
          "name": "gdpapp-raw",
          "bucket-size": "100Gi",
          "location": "ap-southeast-1"
        },
        {
          "name": "gdpapp-curated",
          "bucket-size": "200Gi",
          "location": "ap-southeast-1"
        }
      ],
      "ranger-policies": [
        {
          "schema_name": "gdpapp_db",
          "schema_path": "s3a://gdp-global-common-prod/gdpapp/warehouse/gdpapp.db",
          "schema_admin": ["data-admins"],
          "schema_viewer": ["data-readers"]
        }
      ]
    }
  ]
}
```

### 3.2 Field Descriptions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `meta-data.manifest-schema` | string | Yes | Manifest schema identifier |
| `meta-data.manifest-version` | string | Yes | Manifest version |
| `platform-config[].itam` | int | Yes | ITAM number (e.g., 55547) |
| `platform-config[].tenant` | string | Yes | Tenant name |
| `platform-config[].tenant-short-name` | string | Yes | Short tenant identifier |
| `platform-config[].namespace` | string | Yes | Kubernetes namespace suffix |
| `platform-config[].resource-quotas.cpu` | string | Yes | CPU quota (e.g., "8") |
| `platform-config[].resource-quotas.memory` | string | Yes | Memory quota (e.g., "16384" in Mi) |
| `platform-config[].jobs-queue.cpu` | string | Yes | YuniKorn queue CPU |
| `platform-config[].jobs-queue.memory` | string | Yes | YuniKorn queue memory |
| `platform-config[].object-store-buckets[]` | array | No | MinIO bucket configurations |
| `platform-config[].ranger-policies[]` | array | No | Ranger access policies |

---

## 4. Component Integration Details

### 4.1 GDPTenant Custom Resource

#### 4.1.1 Purpose
Create a GDPTenant CR as a declarative record of tenant configuration, stored in the Kubernetes cluster.

#### 4.1.2 Detailed Steps

1. **Build Tenant Object**
   - **Function**: `BuildTenant(tenantName string, pc model.PlatformConfig) *gdptenantv1.GDPTenant`
   - **Location**: `pkg/tenant/tenant.go:36`
   - **Logic**:
     ```go
     tenantName := fmt.Sprintf("t-%d-%s-%s", pc.Itam, pc.Tenant, pc.TenantShortName)
     // Example: t-55547-gdpapp-app
     ```
   - **Input Parameters**:
     - `tenantName`: Generated as `t-{itam}-{tenant}-{shortName}`
     - `pc`: PlatformConfig from request

2. **Apply to Kubernetes**
   - **Function**: `GDPManager.ApplyTenant(ctx context.Context, tenant *gdptenant.GDPTenant) error`
   - **Location**: `pkg/k8s/tenant_manage.go:33`
   - **Method**: Server-Side Apply (SSA)
   - **API**: `dynamic.Interface.Resource().Apply()`
   - **GVR (GroupVersionResource)**:
     ```go
     Group: "gdp.standardchartered.com"
     Version: "v1"
     Resource: "gdptenants"
     ```
   - **Options**:
     - `FieldManager`: `"gdp-tenant"`
     - `Force`: `true`

#### 4.1.3 API Call Details

```go
tenantSchema := schema.GroupVersionResource{
    Group: "gdp.standardchartered.com", 
    Version: "v1", 
    Resource: "gdptenants"
}

unstructuredObj, err := runtime.DefaultUnstructuredConverter.ToUnstructured(tenant)
tenantUnstructured := &unstructured.Unstructured{Object: unstructuredObj}

_, err = m.cf.localDynamicClient.Resource(tenantSchema).Apply(
    ctx, 
    tenant.Name, 
    tenantUnstructured, 
    metav1.ApplyOptions{
        FieldManager: "gdp-tenant",
        Force: true,
    },
)
```

#### 4.1.4 Sample GDPTenant CR

```yaml
apiVersion: gdp.standardchartered.com/v1
kind: GDPTenant
metadata:
  name: t-55547-gdpapp-app
  namespace: gdp-system
spec:
  itam: 55547
  tenant: gdpapp
  tenant-short-name: app
  namespace: analytics
  resource-quotas:
    cpu: "8"
    memory: "16384"
  jobs-queue:
    cpu: "4"
    memory: "8192"
  object-store-buckets:
    - name: gdpapp-raw
      bucket-size: "100Gi"
      location: ap-southeast-1
```

---

### 4.2 Kubernetes Resources

#### 4.2.1 Namespace Creation

**Function**: `K8SClient.Apply()`  
**Location**: `pkg/tenant/k8s.go:25`

**Steps**:
1. Check if namespace exists using `Get()`
2. Create namespace with OwnerReference to GDPTenant CR
3. Namespace name: `{tenantName}-{namespace}` (e.g., `t-55547-gdpapp-app-analytics`)

**API Call**:
```go
namespace := &corev1.Namespace{
    ObjectMeta: metav1.ObjectMeta{
        Name: ns,
        OwnerReferences: []metav1.OwnerReference{
            {
                APIVersion: "gdp.standardchartered.com/v1",
                Kind:       "GDPTenant",
                Name:       tenantName,
                UID:        uuid,
            },
        },
    },
}
clientset.CoreV1().Namespaces().Create(ctx, namespace, metav1.CreateOptions{})
```

**Parameters**:
- `ns`: `fmt.Sprintf("%s-%s", tenantName, pc.Namespace)`
- `tenantName`: Full tenant name (e.g., `t-55547-gdpapp-app`)
- `uuid`: GDPTenant CR UID

**Sample Input**:
- `tenantName`: `"t-55547-gdpapp-app"`
- `pc.Namespace`: `"analytics"`
- Result: `"t-55547-gdpapp-app-analytics"`

---

#### 4.2.2 ResourceQuota

**Function**: `K8SClient.Apply()`  
**Location**: `pkg/tenant/k8s.go:110`

**Steps**:
1. Create ResourceQuota in namespace
2. Set CPU and Memory limits from `resource-quotas`

**API Call**:
```go
resourceQuota := &corev1.ResourceQuota{
    ObjectMeta: metav1.ObjectMeta{
        Name:      "gdp-tenant-quota",
        Namespace: ns,
    },
    Spec: corev1.ResourceQuotaSpec{
        Hard: corev1.ResourceList{
            corev1.ResourceCPU:    resource.MustParse(cpu),    // e.g., "8"
            corev1.ResourceMemory: resource.MustParse(memory), // e.g., "16384Mi"
        },
    },
}
clientset.CoreV1().ResourceQuotas(ns).Create(ctx, resourceQuota, metav1.CreateOptions{})
```

**Parameters**:
- `cpu`: From `resource-quotas.cpu` (string, e.g., `"8"`)
- `memory`: From `resource-quotas.memory` (string, e.g., `"16384"` - interpreted as Mi)

**Sample Input**:
```json
{
  "resource-quotas": {
    "cpu": "8",
    "memory": "16384"
  }
}
```

---

#### 4.2.3 RBAC - Role & RoleBinding

**Function**: `K8SClient.Apply()`  
**Location**: `pkg/tenant/k8s.go:44-200`

**Steps**:

1. **Create View Role**
   - Name: `{tenantName}-view`
   - Permissions: `get`, `list`, `watch` on pods, pods/log, jobs, events

2. **Create View RoleBinding**
   - Role: `{tenantName}-view`
   - Subject: Group `suz1-apps-gdp-{tenantShortName}-view`
   - Pattern: `suz1-apps-gdp-{trimPrefix(tenantName, "t-")}-view`

3. **Create Spark Job Role**
   - Name: `spark-job-role`
   - Permissions: Full pod management, configmaps, PVCs

4. **Create Spark Job RoleBinding**
   - Role: `spark-job-role`
   - Subjects:
     - ServiceAccount: `vault-auth` (in tenant namespace)
     - ServiceAccount: `gdp-airflow-worker` (in gdp-system)
     - ServiceAccount: `gdp-airflow-webserver` (in gdp-system)

**API Calls**:
```go
// View Role
role := &rbacv1.Role{
    ObjectMeta: metav1.ObjectMeta{
        Name: fmt.Sprintf("%s-view", tenantName),
        Namespace: ns,
        OwnerReferences: []metav1.OwnerReference{ownerRef},
    },
    Rules: []rbacv1.PolicyRule{
        {
            APIGroups: []string{""},
            Resources: []string{"pods"},
            Verbs:     []string{"get", "list", "watch"},
        },
        // ... more rules
    },
}
clientset.RbacV1().Roles(ns).Create(ctx, role, metav1.CreateOptions{})

// View RoleBinding
groupname := fmt.Sprintf("suz1-apps-gdp-%s-view", strings.TrimPrefix(tenantName, "t-"))
rolebinding := &rbacv1.RoleBinding{
    ObjectMeta: metav1.ObjectMeta{
        Name: fmt.Sprintf("%s-view", tenantName),
        Namespace: ns,
    },
    RoleRef: rbacv1.RoleRef{
        APIGroup: "rbac.authorization.k8s.io",
        Kind:     "Role",
        Name:     fmt.Sprintf("%s-view", tenantName),
    },
    Subjects: []rbacv1.Subject{
        {
            Kind: "Group",
            Name: groupname,
        },
    },
}
clientset.RbacV1().RoleBindings(ns).Create(ctx, rolebinding, metav1.CreateOptions{})
```

**Parameters**:
- `tenantName`: Full tenant name (e.g., `t-55547-gdpapp-app`)
- `ns`: Namespace name
- `groupname`: Generated as `suz1-apps-gdp-{tenantShortName}-view`

**Sample Input**:
- `tenantName`: `"t-55547-gdpapp-app"`
- Generated group: `"suz1-apps-gdp-55547-gdpapp-app-view"`

---

### 4.3 YuniKorn Queue Configuration

#### 4.3.1 Purpose
Configure YuniKorn scheduler queues for tenants, setting resource guarantees and maximum limits.

#### 4.3.2 Detailed Steps

1. **Load Existing Config**
   - **Function**: `LoadConfigMaps(cm *corev1.ConfigMap) (*SchedulerConfig, error)`
   - **Location**: `pkg/tenant/yunikorn.go:12`
   - **ConfigMap**: `yunikorn-configs` in `gdp-system` namespace
   - **Key**: `queues.yaml`
   - **Parse**: YAML to `SchedulerConfig` struct

2. **Check Queue Existence**
   - **Function**: `findTenantQueue(config *PartitionConfig, tenantName string) bool`
   - **Location**: `pkg/tenant/yunikorn.go:27`
   - **Logic**: Search in `Partitions[0].Queues[0].Queues[]`

3. **Apply Queue Configuration**
   - **Function**: `ApplyTenantQueue(config *SchedulerConfig, partitionIndex int, queueName string, cpu string, memory string) *SchedulerConfig`
   - **Location**: `pkg/tenant/yunikorn.go:49`
   - **Logic**:
     - If exists: Update resources via `updateTenantQueue()`
     - If not exists: Append new `QueueConfig` to `Queues[0].Queues`

4. **Update ConfigMap**
   - Marshal `SchedulerConfig` to YAML
   - Update ConfigMap: `cm.Data["queues.yaml"] = string(data)`
   - **API**: `clientset.CoreV1().ConfigMaps(namespace).Update()`

#### 4.3.3 API Calls

```go
// Read ConfigMap
cm, err := clientset.CoreV1().ConfigMaps("gdp-system").Get(
    ctx, 
    "yunikorn-configs", 
    metav1.GetOptions{},
)

// Parse YAML
config, err := LoadConfigMaps(cm)

// Apply queue
config = ApplyTenantQueue(config, 0, tenantName, cpu, memory)

// Marshal and update
data, _ := yaml.Marshal(config)
cm.Data["queues.yaml"] = string(data)
clientset.CoreV1().ConfigMaps("gdp-system").Update(ctx, cm, metav1.UpdateOptions{})
```

#### 4.3.4 Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `partitionIndex` | int | Always `0` (default partition) |
| `queueName` | string | Same as `tenantName` |
| `cpu` | string | From `jobs-queue.cpu` (e.g., `"4"`) |
| `memory` | string | From `jobs-queue.memory` (e.g., `"8192"` Mi) |

#### 4.3.5 Queue Configuration Structure

```yaml
partitions:
  - name: default
    queues:
      - name: root
        queues:
          - name: t-55547-gdpapp-app  # tenant queue
            resources:
              guaranteed:
                memory: "8192"
                vcore: "4"
              max:
                memory: "8192"
                vcore: "4"
            submitacl: "*"
```

#### 4.3.6 Sample Input

```json
{
  "jobs-queue": {
    "cpu": "4",
    "memory": "8192"
  }
}
```

---

### 4.4 MinIO Bucket Management

#### 4.4.1 Purpose
Create object storage buckets for tenant data storage.

#### 4.4.2 Detailed Steps

1. **Initialize MinIO Client**
   - **Function**: `NewMinioController(endpoint, accessKey, secretKey string, useSSL bool) *MinioController`
   - **Location**: `pkg/tenant/minio.go:33`
   - **Environment Variables**:
     - `MINIO_ENDPOINT`
     - `MINIO_ACCESS_KEY`
     - `MINO_SECRET_KEY` (note: typo in variable name)

2. **Check Bucket Existence**
   - **Function**: `CheckBucketExist(bucketName string) bool`
   - **Location**: `pkg/tenant/minio.go:99`
   - **API**: `minio.Client.BucketExists(ctx, bucketName)`

3. **Create Bucket**
   - **Function**: `CreateBucket(bucketName, location string) error`
   - **Location**: `pkg/tenant/minio.go:58`
   - **API**: `minio.Client.MakeBucket(ctx, bucketName, MakeBucketOptions{Region: location})`
   - **Error Handling**: If bucket exists, return success

#### 4.4.3 API Calls

```go
// Initialize client
mc := minio.New(endpoint, &minio.Options{
    Creds:  credentials.NewStaticV4(accessKey, secretKey, ""),
    Secure: useSSL,
})

// Check existence
exists, err := mc.client.BucketExists(ctx, bucketName)

// Create bucket
err := mc.client.MakeBucket(ctx, bucketName, minio.MakeBucketOptions{
    Region: location,
})
```

#### 4.4.4 Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `bucketName` | string | From `object-store-buckets[].name` |
| `location` | string | From `object-store-buckets[].location` (default: `"ap-southeast-1"`) |
| `bucketSize` | string | From `object-store-buckets[].bucket-size` (not used in creation) |

#### 4.4.5 Sample Input

```json
{
  "object-store-buckets": [
    {
      "name": "gdpapp-raw",
      "bucket-size": "100Gi",
      "location": "ap-southeast-1"
    },
    {
      "name": "gdpapp-curated",
      "bucket-size": "200Gi",
      "location": "ap-southeast-1"
    }
  ]
}
```

---

### 4.5 Trino Resource Group Configuration

#### 4.5.1 Purpose
Configure Trino query engine resource groups and selectors for tenant compute isolation.

#### 4.5.2 Detailed Steps

1. **Authenticate**
   - **Environment Variables**:
     - `TRINO_USER`
     - `TRINO_PASSWORD`
   - **Auth**: Basic Auth (Base64 encoded)

2. **Check Resource Group Existence**
   - **Function**: `GetResourceGroup(tenantName string, encoded string) (string, error)`
   - **Location**: `pkg/tenant/trino.go:29`
   - **API**: `GET {TrinoEndpoint}/trino/resourcegroup/read`
   - **Response**: Array of resource groups
   - **Logic**: Find group by `name == tenantName`, return `resourceGroupId`

3. **Create Resource Group** (if not exists)
   - **Function**: `CreateResourceGroup(tenantName string, encoded string, TenantNoninteractiveOwner []string) error`
   - **Location**: `pkg/tenant/trino.go:65`
   - **API**: `POST {TrinoEndpoint}/trino/resourcegroup/create`

4. **Create Selector**
   - **Function**: `CreateResourceGroup()` (continued)
   - **API**: `POST {TrinoEndpoint}/trino/selector/create`
   - **Note**: Only creates selector for first owner in `TenantNoninteractiveOwner`

5. **Update Selector** (if group exists)
   - **Function**: `UpdateSelector(groupID, tenantName, encoded string, TenantNoninteractiveOwner []string) error`
   - **Location**: `pkg/tenant/trino.go:162`
   - **API**: `POST {TrinoEndpoint}/trino/selector/update`

#### 4.5.3 API Endpoints

- **Read Resource Groups**: `GET /trino/resourcegroup/read`
- **Create Resource Group**: `POST /trino/resourcegroup/create`
- **Create Selector**: `POST /trino/selector/create`
- **Update Selector**: `POST /trino/selector/update`

**Base URL**: From `constants.TrinoEndpoint` (e.g., `https://trino-gw-prd.sked011.55547.app.standardchartered.com`)

#### 4.5.4 Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `tenantName` | string | Full tenant name |
| `TenantNoninteractiveOwner` | []string | Owner groups for selector |
| `TrinoEndpoint` | string | From constants |

#### 4.5.5 Sample Request/Response

**Create Resource Group Request**:
```json
POST /trino/resourcegroup/create
Authorization: Basic <base64(user:pass)>
Content-Type: application/json

{
  "name": "t-55547-gdpapp-app",
  "softMemoryLimit": "30%",
  "maxQueued": 30,
  "softConcurrencyLimit": 20,
  "hardConcurrencyLimit": 20,
  "jmxExport": true,
  "parent": 1,
  "environment": "trinoskestg"
}
```

**Create Selector Request**:
```json
POST /trino/selector/create
Authorization: Basic <base64(user:pass)>
Content-Type: application/json

{
  "resourceGroupId": "123",
  "priority": 2,
  "userRegex": "suz1-apps-gdp-gdpapp-admin"
}
```

**Sample Input**:
```json
{
  "tenant-noninteractive-owner": ["suz1-apps-gdp-gdpapp-admin"]
}
```

---

### 4.6 Ranger Policy Configuration

#### 4.6.1 Purpose
Configure Apache Ranger data access policies for fine-grained data access control.

#### 4.6.2 Detailed Steps

1. **Authenticate**
   - **Environment Variables**:
     - `RANGER_USER`
     - `RANGER_PASS`
   - **Auth**: HTTP Basic Auth

2. **Apply Policies** (Sequential)
   - **Function**: `Ranger.Apply(tenantName, schemaName, schemaPath, dbName, adminGroups, viewerGroups) error`
   - **Location**: `pkg/tenant/ranger.go:52`
   - **Policies Created**:
     1. S3 Admin Policy (HDFS service)
     2. Table Admin Policy (Hive service)
     3. S3 Viewer Policy (HDFS service)
     4. Table Viewer Policy (Hive service)
     5. Trino Table Admin Policy (Trino service)
     6. Trino Table Viewer Policy (Trino service)

3. **Post Policy**
   - **Function**: `postPolicy(policy PolicyRequest, funcName string) error`
   - **Location**: `pkg/tenant/ranger.go:125`
   - **API**: `POST {baseURL}/service/plugins/policies/apply`
   - **Base URL**: `https://ranger-prd.sked011.55547.app.standardchartered.com`

#### 4.6.3 Policy Details

##### 4.6.3.1 S3 Admin Policy

**Function**: `CreateS3AdminPolicy()`  
**Location**: `pkg/tenant/ranger.go:160`

**Policy Structure**:
```json
{
  "isEnabled": true,
  "service": "fors3",
  "name": "admin-{tenantName}-{schemaName}",
  "policyType": 0,
  "policyPriority": 0,
  "isAuditEnabled": true,
  "resources": {
    "path": {
      "values": [schemaPath],
      "isExcludes": false,
      "isRecursive": true
    }
  },
  "policyItems": [{
    "accesses": [
      {"type": "read", "isAllowed": true},
      {"type": "write", "isAllowed": true},
      {"type": "execute", "isAllowed": true}
    ],
    "groups": adminGroups,
    "delegateAdmin": false
  }],
  "serviceType": "hdfs",
  "isDenyAllElse": false
}
```

##### 4.6.3.2 Table Admin Policy (Hive)

**Function**: `CreateTableAdminPolicy()`  
**Location**: `pkg/tenant/ranger.go:193`

**Policy Structure**:
```json
{
  "isEnabled": true,
  "service": "hive-dev-policy",
  "name": "admin-{tenantName}-{schemaName}-tables",
  "resources": {
    "database": {
      "values": [dbName],
      "isRecursive": false
    },
    "table": {
      "values": ["*"],
      "isRecursive": false
    }
  },
  "policyItems": [{
    "accesses": [
      {"type": "select", "isAllowed": true},
      {"type": "update", "isAllowed": true},
      {"type": "create", "isAllowed": true},
      {"type": "drop", "isAllowed": true},
      {"type": "alter", "isAllowed": true},
      {"type": "all", "isAllowed": true}
    ],
    "groups": adminGroups,
    "delegateAdmin": true
  }],
  "serviceType": "hive"
}
```

##### 4.6.3.3 Trino Table Admin Policy

**Function**: `CreateTrinoTableAdminPolicy()`  
**Location**: `pkg/tenant/ranger.go:301`

**Policy Structure**:
```json
{
  "isEnabled": true,
  "service": "trino_prod",
  "name": "admin-{tenantName}-{schemaName}-tables",
  "resources": {
    "schema": {
      "values": [schemaName],
      "isRecursive": false
    },
    "catalog": {
      "values": ["gdp_global"],
      "isRecursive": false
    },
    "table": {
      "values": ["*"],
      "isRecursive": false
    },
    "column": {
      "values": ["*"],
      "isRecursive": false
    }
  },
  "policyItems": [{
    "accesses": [
      {"type": "select", "isAllowed": true},
      {"type": "insert", "isAllowed": true},
      {"type": "create", "isAllowed": true},
      {"type": "drop", "isAllowed": true},
      {"type": "delete", "isAllowed": true},
      {"type": "all", "isAllowed": true}
    ],
    "groups": adminGroups,
    "delegateAdmin": true
  }],
  "serviceType": "trino"
}
```

#### 4.6.4 Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `tenantName` | string | Full tenant name |
| `schemaName` | string | From `ranger-policies[].schema_name` |
| `schemaPath` | string | From `ranger-policies[].schema_path` (s3a:// prefix removed) |
| `dbName` | string | Same as `schemaName` |
| `adminGroups` | []string | From `ranger-policies[].schema_admin` |
| `viewerGroups` | []string | From `ranger-policies[].schema_viewer` |

#### 4.6.5 API Endpoint

**URL**: `POST https://ranger-prd.sked011.55547.app.standardchartered.com/service/plugins/policies/apply`

**Headers**:
- `Content-Type: application/json`
- `Authorization: Basic <base64(user:pass)>`

**Response**: `200 OK` or `201 Created` on success

#### 4.6.6 Sample Input

```json
{
  "ranger-policies": [
    {
      "schema_name": "gdpapp_db",
      "schema_path": "s3a://gdp-global-common-prod/gdpapp/warehouse/gdpapp.db",
      "schema_admin": ["data-admins"],
      "schema_viewer": ["data-readers"]
    }
  ]
}
```

---

### 4.7 Pod Template Upload

#### 4.7.1 Purpose
Generate and upload Spark Pod template to MinIO for use by Airflow DAGs.

#### 4.7.2 Detailed Steps

1. **Generate Pod Template**
   - **Function**: `UpdatePodTemplate(mc *MinioController, clientset kubernetes.Interface, tenantName string, ns string, secretPath string) error`
   - **Location**: `pkg/tenant/k8s.go:209`
   - **Template Includes**:
     - YuniKorn scheduler annotations
     - Vault integration for secrets
     - Security context (non-root, seccomp)
     - Environment variables (S3, Hive, DataHub endpoints)
     - Volume mounts (truststore, service account tokens)

2. **Upload to MinIO**
   - **Function**: `MinioController.UploadFile(bucketName, objectName string, tenantName string, podTemplate corev1.Pod) error`
   - **Location**: `pkg/tenant/minio.go:112`
   - **Bucket**: `sc-gdp-gbl-common-prod-55547`
   - **Object Path**: `gdp-platform/airflow/dags/{tenantName}/templates/spark-pod-template.yml`
   - **API**: `minio.Client.FPutObject()`

#### 4.7.3 Pod Template Key Features

**Annotations**:
- `yunikorn.apache.org/queue`: `{tenantName}`
- `vault.hashicorp.com/role`: `55547_global_app_k8s_{ns}_role`
- `vault.hashicorp.com/agent-inject-secret-s3-authorizer-secret`: `{secretPath}`

**Security Context**:
- RunAsUser: `10000`
- RunAsGroup: `10000`
- SeccompProfile: `RuntimeDefault`
- Capabilities: Drop all

**Environment Variables**:
- `S3_ENDPOINT_URL`: MinIO endpoint
- `HIVE_ENDPOINT_URL`: Hive metastore
- `S3_AUTHORIZER_SERVER_BASE_URL`: S3 authorizer service
- `DATAHUB_REST_ENDPOINT`: From secret
- `DATAHUB_REST_TOKEN`: From secret

#### 4.7.4 Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `tenantName` | string | Full tenant name |
| `ns` | string | Namespace name |
| `secretPath` | string | From `hcv-secret-path` |

#### 4.7.5 Upload Path

```
Bucket: sc-gdp-gbl-common-prod-55547
Object: gdp-platform/airflow/dags/{tenantName}/templates/spark-pod-template.yml
```

**Example**: `gdp-platform/airflow/dags/t-55547-gdpapp-app/templates/spark-pod-template.yml`

#### 4.7.6 Sample Input

```json
{
  "hcv-secret-path": "secret/data/gdpapp/creds"
}
```

---

### 4.8 Status Update

#### 4.8.1 Purpose
Update GDPTenant CR's Status field to record created resources.

#### 4.8.2 Detailed Steps

1. **Build Status Object**
   - **Location**: `pkg/tenant/tenant.go:225`
   - **Status Fields**:
     ```go
     status := gdptenantv1.GDPTenantStatus{
       Namespace: ns,        // e.g., "t-55547-gdpapp-app-analytics"
       Yunikorn: tenantName, // e.g., "t-55547-gdpapp-app"
     }
     ```

2. **Patch Status**
   - **Function**: `GDPManager.PatchTenantStatus(ctx context.Context, name string, status gdptenant.GDPTenantStatus) error`
   - **Location**: `pkg/k8s/tenant_manage.go:86`
   - **Method**: Merge Patch on subresource `status`
   - **API**: `dynamic.Interface.Resource().Patch(ctx, name, MergePatchType, patchBytes, ..., "status")`

#### 4.8.3 API Call

```go
patch := map[string]interface{}{
    "status": status,
}
patchBytes, _ := json.Marshal(patch)

_, err = m.cf.localDynamicClient.Resource(tenantSchema).
    Patch(ctx, name, types.MergePatchType, patchBytes, metav1.PatchOptions{}, "status")
```

#### 4.8.4 Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | string | GDPTenant CR name |
| `status` | GDPTenantStatus | Status object with namespace and yunikorn queue |

---

## 5. Execution Flow

### 5.1 Sequential Steps (Per Tenant)

```
1. BuildTenant() → GDPTenant CR object
2. ApplyTenant() → Create/Update GDPTenant CR in K8s
3. GetTenant() → Retrieve CR to get UID
4. K8SClient.Apply() → Create K8s resources:
   a. Namespace
   b. ResourceQuota
   c. Role (view)
   d. RoleBinding (view)
   e. Role (spark-job-role)
   f. RoleBinding (sparkjob-binding)
5. LoadConfigMaps() → Read YuniKorn config
6. ApplyTenantQueue() → Add/Update queue
7. Update ConfigMap → Write YuniKorn config back
8. MinioController.CreateBucket() → For each bucket
9. Trino.Apply() → Create/Update resource group & selector
10. Ranger.Apply() → Create 6 policies
11. UpdatePodTemplate() → Generate and upload pod template
12. PatchTenantStatus() → Update CR status
```

### 5.2 Concurrency Model

- **Per Tenant**: Each `PlatformConfig` is processed in a separate goroutine
- **Error Handling**: Errors are logged but don't stop other tenants
- **WaitGroup**: Main goroutine waits for all tenants to complete
- **Error Channel**: Errors collected in `errCh` (currently mostly unused)

**Implementation**: `pkg/tenant/tenant.go:137-243`

---

## 6. Environment Variables

### 6.1 Required Environment Variables

| Variable | Description | Used By | Location |
|----------|-------------|---------|----------|
| `MINIO_ENDPOINT` | MinIO server endpoint | MinIO client | `pkg/k8s/client_factory.go:106` |
| `MINIO_ACCESS_KEY` | MinIO access key | MinIO client | `pkg/k8s/client_factory.go:107` |
| `MINO_SECRET_KEY` | MinIO secret key (note typo) | MinIO client | `pkg/k8s/client_factory.go:108` |
| `TRINO_USER` | Trino API username | Trino client | `pkg/tenant/trino.go:137` |
| `TRINO_PASSWORD` | Trino API password | Trino client | `pkg/tenant/trino.go:138` |
| `RANGER_USER` | Ranger API username | Ranger client | `pkg/tenant/ranger.go:144` |
| `RANGER_PASS` | Ranger API password | Ranger client | `pkg/tenant/ranger.go:145` |

---

## 7. Error Handling

### 7.1 Error Types

1. **JSON Parsing Errors**: Return 400 Bad Request
2. **Kubernetes API Errors**: Log and continue (non-blocking)
3. **MinIO Errors**: Log and continue
4. **Trino/Ranger Errors**: Log and continue

### 7.2 Error Aggregation

- Errors are collected in `errCh` channel (defined but mostly unused)
- Final response includes all errors if any occurred
- Individual tenant failures don't block others

**Implementation**: `pkg/tenant/tenant.go:134, 248-257`

---

## 8. Sample Complete Request

```bash
curl -X POST http://localhost:6443/v1/gdp/tenant/create \
  -H "Content-Type: application/json" \
  -d '{
    "meta-data": {
      "manifest-schema": "gdp-tenant",
      "manifest-version": "v1"
    },
    "platform-config": [
      {
        "itam": 55547,
        "tenant": "gdpapp",
        "tenant-short-name": "app",
        "namespace": "analytics",
        "resource-quotas": {
          "cpu": "8",
          "memory": "16384"
        },
        "jobs-queue": {
          "cpu": "4",
          "memory": "8192"
        },
        "object-store-buckets": [
          {
            "name": "gdpapp-raw",
            "bucket-size": "100Gi",
            "location": "ap-southeast-1"
          }
        ],
        "ranger-policies": [
          {
            "schema_name": "gdpapp_db",
            "schema_path": "s3a://gdp-global-common-prod/gdpapp/warehouse/gdpapp.db",
            "schema_admin": ["data-admins"],
            "schema_viewer": ["data-readers"]
          }
        ]
      }
    ]
  }'
```

---

## 9. Constants and Configuration

### 9.1 Key Constants

**Location**: `pkg/constants/const.go`

```go
const GDPNamespace = "gdp-system"
const YunikornNamespace = "gdp-system"
const YuniKornConfigMapName = "yunikorn-configs"
const TrinoNamespace = "gdp-system"
const TrinoConfigMapName = "gdp-trino-coordinator-resource-groups"
const TrinoEndpoint = "https://trino-gw-prd.sked011.55547.app.standardchartered.com"
```

### 9.2 Ranger Base URL

**Location**: `pkg/tenant/ranger.go:15`

```go
const baseURL = "https://ranger-prd.sked011.55547.app.standardchartered.com"
```

---

## 10. References

- **Kubernetes API**: https://kubernetes.io/docs/reference/
- **YuniKorn**: https://yunikorn.apache.org/
- **MinIO**: https://min.io/docs/
- **Trino**: https://trino.io/docs/
- **Apache Ranger**: https://ranger.apache.org/
- **Server-Side Apply**: https://kubernetes.io/docs/reference/using-api/server-side-apply/

---

## 11. Appendix: Code Locations

| Component | File | Key Functions |
|-----------|------|---------------|
| API Handler | `pkg/tenant/tenant.go` | `CreateTenant()`, `ApplyTenant()`, `BuildTenant()` |
| K8s Resources | `pkg/tenant/k8s.go` | `K8SClient.Apply()`, `UpdatePodTemplate()` |
| YuniKorn | `pkg/tenant/yunikorn.go` | `LoadConfigMaps()`, `ApplyTenantQueue()` |
| MinIO | `pkg/tenant/minio.go` | `CreateBucket()`, `UploadFile()` |
| Trino | `pkg/tenant/trino.go` | `Apply()`, `CreateResourceGroup()` |
| Ranger | `pkg/tenant/ranger.go` | `Apply()`, `CreateS3AdminPolicy()`, etc. |
| CR Management | `pkg/k8s/tenant_manage.go` | `ApplyTenant()`, `PatchTenantStatus()` |
| Models | `pkg/model/model.go` | `AppManifest`, `PlatformConfig` |
| Router | `pkg/router/router.go` | `Init()`, route registration |
| Main | `main.go` | Server startup, initialization |

---

## 12. Tenant Naming Conventions

### 12.1 Tenant Name Format

```
t-{itam}-{tenant}-{tenantShortName}
```

**Example**: `t-55547-gdpapp-app`

### 12.2 Namespace Format

```
{tenantName}-{namespace}
```

**Example**: `t-55547-gdpapp-app-analytics`

### 12.3 Group Name Format

```
suz1-apps-gdp-{tenantShortName}-{role}
```

**Example**: `suz1-apps-gdp-app-view`

---

## 13. Security Considerations

### 13.1 Pod Security

- Non-root user (UID 10000)
- Seccomp profile: RuntimeDefault
- All capabilities dropped
- Service account token projection with expiration

### 13.2 Vault Integration

- Vault agent sidecar injection
- Secret injection via annotations
- Service account token for Vault authentication

### 13.3 RBAC

- Least privilege principle
- Separate roles for view and admin operations
- Group-based access control

---

## 14. Monitoring and Metrics

### 14.1 Prometheus Metrics

**Endpoint**: `GET /v1/gdp/metrics`

**Metrics Collected**:
- `gdp_api_onboard_tenant_status`: Tenant status gauge
- `gdp_api_onboard_tenant_resource_request`: Resource request gauge
- `gdp_api_onboard_tenant_resource_limit`: Resource limit gauge

**Collection Interval**: Every 3 seconds

**Implementation**: `pkg/metrics/metrics.go`

---

## 15. Troubleshooting

### 15.1 Common Issues

1. **Namespace Creation Fails**
   - Check RBAC permissions
   - Verify cluster connectivity

2. **YuniKorn ConfigMap Update Fails**
   - Check ConfigMap exists
   - Verify write permissions

3. **MinIO Bucket Creation Fails**
   - Verify MinIO credentials
   - Check network connectivity

4. **Trino Resource Group Creation Fails**
   - Verify Trino API credentials
   - Check endpoint accessibility

5. **Ranger Policy Creation Fails**
   - Verify Ranger credentials
   - Check policy service names

### 15.2 Logging

All components use `klog` for logging. Set log level via `-v` flag:

```bash
./gdp-api -v=2
```

---

## 16. Future Enhancements

- Grafana dashboard integration
- ResourceQuota enhancements
- Pod limit enforcement
- Default configmap management
- Scheduled tenant reconciliation
- Support for additional storage backends
- Multi-cluster support

---

**Document Version**: 1.0  
**Last Updated**: 2025  
**Maintained By**: GDP Platform Team

