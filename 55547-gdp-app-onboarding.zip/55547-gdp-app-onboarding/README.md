# GDP Tenant Onboarding - Python Implementation

This directory contains a Python implementation of the GDP Tenant Onboarding pipeline.

## Features

- **Automated Tenant Onboarding:**
  Parses tenant manifests and provisions all required resources automatically.
- **Kubernetes Native:**
  Creates namespaces, resource quotas, and YuniKorn queues for each tenant.
- **Object Storage Integration:**
  Registers MinIO buckets for tenant data storage.
- **Compute Resource Management:**
  Configures Trino resource groups and selectors for tenant compute isolation.
- **Data Governance:**
  Applies Ranger policies for fine-grained data access control.
- **Extensible Workflow:**
  Supports integration with Airflow, DataHub, Kafka, and more.
- **Concurrent Processing:**
  Handles multiple tenants in parallel with robust error aggregation.


## Structure

```
python/
├── src/
│   ├── main.py                    # Main entry point for full pipeline
│   ├── steps/                     # Pipeline step modules
│   │   ├── __init__.py
│   │   ├── gdptenant_cr.py       # GDPTenant CR creation
│   │   ├── k8s_resources.py      # K8s resources (Namespace, Quota, RBAC)
│   │   ├── yunikorn_queue.py     # YuniKorn queue configuration
│   │   ├── minio_bucket.py       # MinIO bucket creation
│   │   ├── trino_resource_group.py # Trino resource group configuration
│   │   ├── ranger_policy.py      # Ranger policy configuration
│   │   └── pod_template.py       # Pod template generation and upload
│   ├── utils/                     # Utility functions
│   │   ├── __init__.py
│   │   └── utils.py              # Common utility functions
│   └── tools/                     # Standalone tools
│       ├── __init__.py
│       └── pod_template_generator.py # Standalone pod template generator
├── onboarding_manifest/          # Example manifest files
├── pod_template/                 # Example pod template outputs
└── requirements.txt             # Python dependencies
```

## Installation

```bash
pip install -r requirements.txt
```

## Usage

### Full Onboarding Pipeline

Run the complete onboarding pipeline:

```bash
cd python/src
python main.py --manifest ../onboarding_manifest/CEMSCOMP_ranger-access.yaml
```

Or from project root:

```bash
python python/src/main.py --manifest python/onboarding_manifest/CEMSCOMP_ranger-access.yaml
```

Options:
- `--manifest`: Path to manifest.yml file (required)
- `--dry-run`: Run in dry-run mode (no actual changes)
- `--output-dir`: Output directory for generated files (default: output)

### Standalone Pod Template Generator

Generate only pod templates without running the full pipeline:

```bash
cd python/src/tools
python pod_template_generator.py --manifest ../../onboarding_manifest/CEMSCOMP_ranger-access.yaml --output-dir ./output
```

Or from project root:

```bash
python python/src/tools/pod_template_generator.py --manifest python/onboarding_manifest/CEMSCOMP_ranger-access.yaml --output-dir ./output
```

Options:
- `--manifest`: Path to manifest.yml file (required)
- `--output-dir`: Output directory (default: output)
- `--print`: Print YAML to stdout

## Environment Variables

The following environment variables are required for the full pipeline:

### MinIO
- `MINIO_ENDPOINT`: MinIO server endpoint
- `MINIO_ACCESS_KEY`: MinIO access key
- `MINO_SECRET_KEY`: MinIO secret key (note: typo in variable name)

### Trino
- `TRINO_USER`: Trino API username
- `TRINO_PASSWORD`: Trino API password
- `TRINO_ENDPOINT`: Trino endpoint (optional, has default)

### Ranger
- `RANGER_USER`: Ranger API username
- `RANGER_PASS`: Ranger API password
- `RANGER_BASE_URL`: Ranger base URL (optional, has default)

### Kubernetes
Kubernetes configuration is automatically loaded from:
- In-cluster config (if running in K8s)
- `~/.kube/config` (if running locally)

## Pipeline Steps

The pipeline executes the following steps for each tenant:

1. **GDPTenant CR**: Create/update Custom Resource
2. **K8s Resources**: Create Namespace, ResourceQuota, Roles, RoleBindings
3. **YuniKorn Queue**: Update queue configuration
4. **MinIO Buckets**: Create object storage buckets
5. **Trino Resource Group**: Configure resource groups and selectors
6. **Ranger Policies**: Apply data access policies
7. **Pod Template**: Generate and upload Spark pod template

## Example Manifest Format

See `onboarding_manifest/` directory for example manifest files.

```yaml
meta-data:
  manifest-schema: v1
  manifest-version: "1.0"
platform-config:
  - itam: 55547
    tenant: rds
    tenant-short-name: cemscomp
    namespace: default
    hcv-secret-path: secret/data/gdpapp/creds
    jobs-queue:
      cpu: "10"
      memory: 80Gi
    resource-quotas:
      cpu: "8"
      memory: 2Gi
    object-store-buckets:
      - name: sc-rds-gbl-grp-sit-55547-cemscomp
        bucket-size: 10Gi
    ranger-policies:
      - schema_name: cemscomp_hk_sri_open
        schema_path: s3a://sc-rds-gbl-grp-sit-55547-cemscomp/cemscomp/warehouse/gdp_global/cemscomp_hk_sri_open
        schema_admin: [sgz1-apps-rds-cemscomp-batch-fullaccess-dev]
        schema_viewer: [sgz1-apps-rds-batch-readonly-dev]
```

## Notes

- The Python implementation mirrors the Go implementation in `pkg/tenant/`
- Each step is implemented as a separate module for maintainability
- Error handling follows the same pattern as the Go version
- The pod template generator can be used independently

